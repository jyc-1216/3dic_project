# ============================================================
# Basic-die single-die IJTAG flow configuration
#
# All relative paths are interpreted from basic_die_single_flow/.
# Edit this file before running the flow.
# ============================================================

set BASIC_DIE_TOP       basic_die_top
set RTL_DESIGN_ID       rtl1
set GATE_DESIGN_ID      gate
set TESSENT_TCK_PERIOD  100.0

# Set to 0 for standard Design Compiler compile.
# Set to 1 only when a DC Ultra license is available.
set USE_COMPILE_ULTRA   0

# Tessent v2021.3 examples use "icl_extract".  If the generated
# SDC documents another spelling, change this value accordingly.
set PRESERVE_USE_CASE   icl_extract

# Golden functional RTL.  The top hierarchy is expected to contain u_alu.
set BASIC_DIE_RTL_FILES [list \
    rtl/basic_die_alu_core.v \
    rtl/basic_die_top.v]

# Optional user functional SDC.  Leave empty for the first combinational
# ALU bring-up when no functional clock or I/O constraints are required.
set FUNCTIONAL_SDC ""

# Optional standard-cell Verilog interface model for Tessent gate import.
# This is NOT the Synopsys .db file.  Leave empty if the gate netlist can
# be elaborated without it, then inspect unresolved-module warnings.
set STDCELL_INTERFACE_VERILOG ""

# Full standard-cell Verilog simulation models for gate-level simulation.
# Multiple files may be listed.  Synopsys .db files cannot be used here.
set STDCELL_SIM_VERILOG [list]

# Output locations.
set GENERATED_DIR generated
set TSDB_DIR      tsdb_basic
set REPORT_DIR    reports

