# ============================================================
# Stage 1 - Tessent RTL IJTAG insertion and ICL/PDL extraction
# Run with: tessent -shell -dofile tcl/01_basic_die_insert_and_extract_icl.tcl
# ============================================================

set script_dir   [file dirname [file normalize [info script]]]
set project_root [file dirname $script_dir]
cd $project_root

source [file join $project_root config basic_die_flow_config.tcl]

set generated_dir [file normalize $GENERATED_DIR]
set tsdb_dir      [file normalize $TSDB_DIR]
set inserted_rtl  [file join $generated_dir basic_die_ijtag_inserted.v]
set dc_import_tcl [file join $generated_dir basic_die_dc_import.tcl]

file mkdir $generated_dir
file mkdir $tsdb_dir

foreach rtl_file $BASIC_DIE_RTL_FILES {
    set rtl_path [file normalize $rtl_file]
    if {![file exists $rtl_path]} {
        error "Missing RTL file: $rtl_path"
    }
}

set_context dft -rtl -design_id $RTL_DESIGN_ID
set_tsdb_output_directory $tsdb_dir

# This proof-of-concept flow intentionally does not call read_cell_library.
# The generated Synopsys .db library is used later by Design Compiler only.
foreach rtl_file $BASIC_DIE_RTL_FILES {
    read_verilog [file normalize $rtl_file]
}

set_current_design $BASIC_DIE_TOP
set_design_level chip

# External IEEE 1149.1 TAP pins already declared in basic_die_top RTL.
set_attribute_value tck  -name function -value tck
set_attribute_value tms  -name function -value tms
set_attribute_value tdi  -name function -value tdi
set_attribute_value tdo  -name function -value tdo
set_attribute_value trst -name function -value trst

check_design_rules

# One TAP, one SIB, and one 30-bit TDR.
# TDR[18:0] controls the ALU; TDR[29:19] observes the ALU result/status.
set dft_spec [create_dft_specification]

read_config_data -in $dft_spec -from_string {
    IjtagNetwork {
        HostScanInterface(ijtag) {
            Interface {
                tck : tck;
            }

            Tap(single) {
                HostIjtag(1) {
                    Sib(alu) {
                        Tdr(alu_tdr) {
                            length : 30;

                            DataOutPorts {
                                connection(7:0)   : u_alu/operand_a[7:0];
                                connection(15:8)  : u_alu/operand_b[7:0];
                                connection(18:16) : u_alu/opcode[2:0];
                            }

                            DataInPorts {
                                connection(26:19) : u_alu/result[7:0];
                                connection(27)    : u_alu/zero_flag;
                                connection(28)    : u_alu/carry_flag;
                                connection(29)    : u_alu/overflow_flag;
                            }
                        }
                    }
                }
            }
        }
    }
}

report_config_data $dft_spec
process_dft_specification

# Creates the RTL ICL, consolidated PDL, and Tessent SDC in the TSDB.
extract_icl

# Save the rtl1 full view and its ICL/PDL/DFT metadata.
write_design -tsdb -verbose

# Human-readable post-insertion RTL for inspection.
write_design -output_file $inserted_rtl -replace

# Synopsys DC loading script.  DC must source this file instead of reading
# the golden RTL and inserted RTL independently.
write_design_import_script \
    $dc_import_tcl \
    -replace \
    -use_relative_path_to $project_root

puts "Stage 1 completed"
puts "Inserted RTL : $inserted_rtl"
puts "DC import Tcl: $dc_import_tcl"
puts "TSDB         : $tsdb_dir"
exit

