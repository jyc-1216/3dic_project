# ============================================================
# Stage 2 - Synopsys Design Compiler synthesis
# Run with: dc_shell -f tcl/02_basic_die_dc_synthesis.tcl
#
# Required environment variables:
#   DC_TARGET_LIBRARY=/path/to/standard_cells.db
#   DC_LINK_LIBRARY=/path/to/standard_cells.db
# Optional:
#   DC_SEARCH_PATH=/path/one:/path/two
# ============================================================

set script_dir   [file dirname [file normalize [info script]]]
set project_root [file dirname $script_dir]
cd $project_root

source [file join $project_root config basic_die_flow_config.tcl]

foreach env_var {DC_TARGET_LIBRARY DC_LINK_LIBRARY} {
    if {![info exists env($env_var)] || $env($env_var) eq ""} {
        error "Missing environment variable: $env_var"
    }
}

set generated_dir [file normalize $GENERATED_DIR]
set report_dir    [file normalize [file join $REPORT_DIR dc_basic]]
set tsdb_dir      [file normalize $TSDB_DIR]
set import_tcl    [file join $generated_dir basic_die_dc_import.tcl]
set gate_netlist  [file join $generated_dir basic_die_top.vg]
set output_ddc    [file join $generated_dir basic_die_top.ddc]
set merged_sdc    [file join $generated_dir basic_die_top_merged.sdc]

file mkdir $generated_dir
file mkdir $report_dir

if {![file exists $import_tcl]} {
    error "Missing Tessent-generated DC import Tcl: $import_tcl"
}

set target_library [split $env(DC_TARGET_LIBRARY) ":"]
set link_library   [concat "*" [split $env(DC_LINK_LIBRARY) ":"]]

if {[info exists env(DC_SEARCH_PATH)] && $env(DC_SEARCH_PATH) ne ""} {
    set search_path [concat $search_path [split $env(DC_SEARCH_PATH) ":"]]
}

# Loads the complete Tessent-inserted hierarchy: basic die, TAP, SIB, TDR,
# and IJTAG mux/control logic.  Do not read the inserted .v a second time.
source $import_tcl

current_design $BASIC_DIE_TOP
link

if {$FUNCTIONAL_SDC ne ""} {
    set functional_sdc [file normalize $FUNCTIONAL_SDC]
    if {![file exists $functional_sdc]} {
        error "Missing functional SDC: $functional_sdc"
    }
    read_sdc $functional_sdc
}

set tessent_sdc [file join \
    $tsdb_dir \
    dft_inserted_designs \
    ${BASIC_DIE_TOP}_${RTL_DESIGN_ID}.dft_inserted_design \
    ${BASIC_DIE_TOP}.sdc]

if {![file exists $tessent_sdc]} {
    error "Missing Tessent-generated SDC: $tessent_sdc"
}

# The Tessent SDC defines Tcl procedures; it must be sourced.
source $tessent_sdc

foreach required_proc {
    tessent_set_default_variables
    tessent_set_non_modal
    tessent_get_preserve_instances
    tessent_get_size_only_instances
    tessent_get_optimize_instances
} {
    if {[llength [info commands $required_proc]] == 0} {
        error "Tessent SDC did not define required procedure: $required_proc"
    }
}

tessent_set_default_variables
set tessent_tck_period $TESSENT_TCK_PERIOD

set_app_var timing_enable_multiple_clocks_per_reg true
tessent_set_non_modal

# Preserve Tessent persistent modules/cells used as ICL mapping anchors.
set_app_var \
    compile_enable_constant_propagation_with_no_boundary_opt false
set_app_var compile_seqmap_propagate_high_effort false
set_app_var compile_delete_unloaded_sequential_cells false

set preserve_instances \
    [tessent_get_preserve_instances $PRESERVE_USE_CASE]

if {[sizeof_collection $preserve_instances] > 0} {
    set_ungroup $preserve_instances false
    set_boundary_optimization $preserve_instances false
}

set size_only_instances [tessent_get_size_only_instances]

if {[sizeof_collection $size_only_instances] > 0} {
    set_size_only -all_instances $size_only_instances
}

set optimize_instances [tessent_get_optimize_instances]

if {[sizeof_collection $optimize_instances] > 0} {
    set_boundary_optimization $optimize_instances true
}

# Record the exact persistent objects returned by the generated SDC.
set preserve_report [open [file join $report_dir tessent_preserve_instances.rpt] w]
foreach_in_collection inst $preserve_instances {
    puts $preserve_report [get_object_name $inst]
}
close $preserve_report

redirect -file [file join $report_dir check_design_pre.rpt] {
    check_design
}
redirect -file [file join $report_dir check_timing_pre.rpt] {
    check_timing
}
redirect -file [file join $report_dir clocks_pre.rpt] {
    report_clock
}

if {$USE_COMPILE_ULTRA} {
    puts "Using compile_ultra -no_autoungroup"
    compile_ultra -no_autoungroup
} else {
    puts "Using standard Design Compiler compile"
    compile -map_effort high
}

redirect -file [file join $report_dir check_design_post.rpt] {
    check_design
}
redirect -file [file join $report_dir qor.rpt] {
    report_qor
}
redirect -file [file join $report_dir area.rpt] {
    report_area -hierarchy
}
redirect -file [file join $report_dir timing.rpt] {
    report_timing -max_paths 20
}
redirect -file [file join $report_dir references.rpt] {
    report_reference -hierarchy
}

# Stable legal Verilog names.  Gate import later updates ICL attributes to
# these synthesized names.
change_names -rules verilog -hierarchy

write -format verilog -hierarchy -output $gate_netlist
write -format ddc     -hierarchy -output $output_ddc
write_sdc $merged_sdc

puts "Stage 2 completed"
puts "Gate netlist: $gate_netlist"
puts "DDC         : $output_ddc"
puts "Merged SDC  : $merged_sdc"
quit

