# ============================================================
# Stage 3 - Import the DC .vg into Tessent and map RTL ICL to gates
# Run with: tessent -shell -dofile tcl/03_basic_die_gate_import_and_map_icl.tcl
# ============================================================

set script_dir   [file dirname [file normalize [info script]]]
set project_root [file dirname $script_dir]
cd $project_root

source [file join $project_root config basic_die_flow_config.tcl]

set tsdb_dir     [file normalize $TSDB_DIR]
set gate_netlist [file normalize [file join $GENERATED_DIR basic_die_top.vg]]

if {![file exists $gate_netlist]} {
    error "Missing DC gate netlist: $gate_netlist"
}

set_context dft -no_rtl -design_id $GATE_DESIGN_ID
set_tsdb_output_directory $tsdb_dir

# A Synopsys .db file is not read by Tessent.  If a standard-cell Verilog
# interface model is available, load it before the mapped netlist.
if {$STDCELL_INTERFACE_VERILOG ne ""} {
    set interface_model [file normalize $STDCELL_INTERFACE_VERILOG]
    if {![file exists $interface_model]} {
        error "Missing standard-cell interface model: $interface_model"
    }
    read_verilog $interface_model -interface_only
} else {
    puts "WARNING: STDCELL_INTERFACE_VERILOG is empty"
    puts "         Inspect unresolved/black-box messages carefully"
}

read_verilog $gate_netlist

# Load the rtl1 ICL/PDL/DFT collateral, without reloading the old RTL HDL.
read_design \
    $BASIC_DIE_TOP \
    -design_id $RTL_DESIGN_ID \
    -no_hdl \
    -verbose

set_current_design $BASIC_DIE_TOP
set_design_level chip

# Correlate RTL ICL modules/ports/persistent anchors with DC output names.
update_icl_attributes_from_design -verbose

check_design_rules

# Save the correlated gate view in the same TSDB.
write_design -tsdb -verbose

puts "Stage 3 completed"
puts "Gate view saved as design_id: $GATE_DESIGN_ID"
exit

