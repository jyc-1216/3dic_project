# ============================================================
# Stage 4 - Generate IJTAG verification patterns from gate view
# Run with: tessent -shell -dofile tcl/04_basic_die_gate_ijtag_verify.tcl
# ============================================================

set script_dir   [file dirname [file normalize [info script]]]
set project_root [file dirname $script_dir]
cd $project_root

source [file join $project_root config basic_die_flow_config.tcl]

set tsdb_dir [file normalize $TSDB_DIR]

set_context patterns -ijtag -design_id $GATE_DESIGN_ID
set_tsdb_output_directory $tsdb_dir

read_design \
    $BASIC_DIE_TOP \
    -design_id $GATE_DESIGN_ID \
    -verbose

set_current_design $BASIC_DIE_TOP
check_design_rules

# The generated PatternsSpecification creates ICL-network access tests.
# These tests exercise access to TDRs through iWrite/iRead operations and
# retarget them through the TAP/SIB network.
set pattern_spec [create_patterns_specification]
report_config_data $pattern_spec
process_patterns_specification

if {[llength $STDCELL_SIM_VERILOG] == 0} {
    puts "WARNING: Patterns were generated, but simulation was not run"
    puts "         Set STDCELL_SIM_VERILOG in the config to full Verilog models"
    exit
}

set simulation_source_args [list]
foreach sim_file $STDCELL_SIM_VERILOG {
    set sim_path [file normalize $sim_file]
    if {![file exists $sim_path]} {
        error "Missing simulation model: $sim_path"
    }
    lappend simulation_source_args -v $sim_path
}

eval set_simulation_library_sources $simulation_source_args

run_testbench_simulations
check_testbench_simulations -report_status

puts "Stage 4 completed"
exit

