# Three-Die Bidirectional RTL DWR Candidate Demonstrator

This revision models the intended physical stack:

```text
SRAM Readout 2 die (top)
SRAM Readout 1 die (middle)
Basic ALU die (bottom)
```

The ALU and temperature-core behavior remains unchanged.  All core RTL,
generated wrappers, and the smoke-test testbench use Verilog-2001 syntax
with the company-standard `.v` extension.  Tcl generates all three wrapper
tops.

## 1. Adjacent-die DWR topology

Only adjacent dies are directly connected:

- Link 0: Basic ALU die ↔ SRAM Readout 1 die.
- Link 1: SRAM Readout 1 die ↔ SRAM Readout 2 die.

Every physical link has an independent 8-bit path in each direction.  The
middle SRAM Readout die therefore contains two DWR candidate banks:

- `u_dwr_down` faces the Basic die.
- `u_dwr_up` faces SRAM Readout 2.

The middle SRAM Readout die also performs the minimum forwarding needed to exercise
the entire stack:

- Upward: the ALU result received from the Basic die is forwarded to SRAM Readout 2.
- Downward: a TDR control bit selects either SRAM Readout 1 temperature or forwarded
  SRAM Readout 2 temperature for transmission to the Basic die.

No direct wire skips over SRAM Readout 1.

## 2. Functional and sequential boundary behavior

### CORE/functional mode

`boundary_seq_mode = 0`

- The ALU remains a zero-latency combinational core.
- The ALU result propagates Basic → SRAM Readout 1 → SRAM Readout 2.
- SRAM Readout 1 can return its local temperature to the Basic die.
- SRAM Readout 1 can instead forward SRAM Readout 2 temperature to the Basic die.

### SEQ boundary mode

`boundary_seq_mode = 1`

- Each physical die boundary is driven from its TX candidate FF bank.
- Each RX candidate bank stores the value observed on that boundary.
- The middle die controls its down-facing and up-facing boundaries
  independently.

These are still RTL DWR candidate FFs.  They are not presented as completed
gate-level Tessent DWR scan stitching.

## 3. TDO readback behavior

The IEEE 1687 TDR remains the legal path to TDO:

1. Select CORE or SEQ source.
2. Capture the selected value into the TDR.
3. Shift the TDR through the TAP to TDO.

The middle SRAM Readout die has one additional selector because it has two RX
candidate banks:

- down-facing SEQ: value captured from the Basic die;
- up-facing SEQ: value captured from SRAM Readout 2.

## 4. TAP/STAP roles

| Die | Physical role | Local IEEE 1687 | Downstream stack access |
|---|---|---|---|
| Basic ALU | bottom | `HostIjtag(1)` / `Sib(alu)` | `HostStap(s1)` to SRAM Readout 1 |
| SRAM Readout 1 | middle | `HostIjtag(1)` / `Sib(temperature_mid)` | `HostStap(s2)` to SRAM Readout 2 |
| SRAM Readout 2 | top | `HostIjtag(1)` / `Sib(temperature_top)` | no `HostStap` |

For both the Basic and middle dies, `HostIjtag` and `HostStap` are declared in
the same `read_config_data` block under `Tap(main)`.

## 5. TDR maps

### Basic ALU TDR: 33 bits

| Bits | Direction | Function |
|---|---|---|
| `[7:0]` | TDR to design | `operand_a` |
| `[15:8]` | TDR to design | `operand_b` |
| `[18:16]` | TDR to design | `opcode` |
| `[19]` | TDR to design | `0=ALU CORE`, `1=down-facing RX candidate` |
| `[20]` | TDR to design | DWR capture |
| `[21]` | TDR to design | boundary `0=CORE`, `1=TX FF` |
| `[29:22]` | design to TDR | selected readback |
| `[30]` | design to TDR | zero flag |
| `[31]` | design to TDR | carry flag |
| `[32]` | design to TDR | overflow flag |

### Middle SRAM Readout TDR: 17 bits

| Bits | Direction | Function |
|---|---|---|
| `[7:0]` | design to TDR | selected readback |
| `[8]` | design to TDR | `temperature_valid` |
| `[9]` | TDR to design | `sample_enable` |
| `[10]` | TDR to design | `0=local CORE`, `1=SEQ candidate` |
| `[11]` | TDR to design | SEQ side: `0=down`, `1=up` |
| `[12]` | TDR to design | down-facing capture |
| `[13]` | TDR to design | up-facing capture |
| `[14]` | TDR to design | down boundary `0=CORE`, `1=TX FF` |
| `[15]` | TDR to design | up boundary `0=forward`, `1=TX FF` |
| `[16]` | TDR to design | data to Basic: `0=SRAM Readout 1`, `1=SRAM Readout 2` |

### Top SRAM Readout TDR: 13 bits

| Bits | Direction | Function |
|---|---|---|
| `[7:0]` | design to TDR | selected readback |
| `[8]` | design to TDR | `temperature_valid` |
| `[9]` | TDR to design | `sample_enable` |
| `[10]` | TDR to design | `0=local CORE`, `1=down-facing RX candidate` |
| `[11]` | TDR to design | DWR capture |
| `[12]` | TDR to design | boundary `0=CORE`, `1=TX FF` |

## 6. Generate wrapper RTL

```sh
tclsh scripts/generate_dwr_wrappers.tcl generated_rtl
```

Generated tops:

- `basic_die_alu_dwr_top.v`
- `middle_sram_readout_die_temperature_dwr_top.v`
- `top_sram_readout_die_temperature_dwr_top.v`

## 7. Tessent RTL insertion

Run from this package directory:

```sh
tessent -shell -dofile scripts/basic_die_insert_1687_1838_dwr.tcl
tessent -shell -dofile scripts/middle_sram_readout_die_insert_1687_1838_dwr.tcl
tessent -shell -dofile scripts/top_sram_readout_die_insert_1687_1838_dwr.tcl
```

If the generated main-TAP path differs in the installed Tessent release:

```sh
setenv MAIN_TAP_CONFIG_PATH \
  'IjtagNetwork/HostScanInterface(tap)/Tap(<actual_id>)'
```

After each Tessent-generated DC import script, source:

```tcl
source scripts/dc_preserve_dwr_candidates.tcl
```

## 8. RTL smoke test

Example with Synopsys VCS:

```sh
vcs -v2001 \
  rtl/rtl_bidirectional_dwr_candidate.v \
  rtl/rtl_readback_mux.v \
  tb/tb_three_die_dwr.v \
  -top tb_three_die_dwr \
  -o simv

./simv
```

Expected message:

```text
PASS: three-die bidirectional DWR forwarding and CORE/SEQ readback
```

The test verifies:

- ALU data reaches SRAM Readout 2 through SRAM Readout 1.
- SRAM Readout 1 temperature reaches the Basic die.
- SRAM Readout 2 temperature reaches the Basic die through SRAM Readout 1.
- all four physical DWR interfaces capture RX/TX boundary values;
- sequential boundary drive preserves the captured values;
- middle-die CORE, down-facing SEQ, and up-facing SEQ readback selection.

## 9. Current claim boundary

This package demonstrates:

> RTL-level automatic pre-insertion of bidirectional DWR candidate FFs for a
> three-die stack, coexisting with IEEE 1687 and IEEE 1838 access logic.

It does not yet claim completed Tessent DWR promotion or scan stitching.  The
later gate-level flow still requires a Tessent-readable scan-cell library and:

```tcl
analyze_wrapper_cells
analyze_scan_chains
insert_test_logic
```
