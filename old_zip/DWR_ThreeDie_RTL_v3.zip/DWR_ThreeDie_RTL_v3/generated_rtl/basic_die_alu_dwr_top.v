module basic_die_alu_dwr_top (
    input              tck,
    input              tms,
    input              tdi,
    output             tdo,
    input              trst,

    input              dwr_clk,

    output       [7:0] basic_to_sram_readout1,
    input        [7:0] sram_readout1_to_basic,

    output       [7:0] alu_operand_a,
    output       [7:0] alu_operand_b,
    output       [2:0] alu_opcode,
    output       [7:0] alu_result,
    output             alu_zero_flag,
    output             alu_carry_flag,
    output             alu_overflow_flag,

    output       [7:0] remote_sram_readout_live,
    output       [7:0] remote_sram_readout_snapshot
);

    wire       readback_seq_select;
    wire       dwr_capture_enable;
    wire       dwr_boundary_seq_mode;
    wire [7:0] dwr_rx_candidate_value;
    wire [7:0] dwr_tx_candidate_value;
    wire [7:0] alu_tdo_readback;

    base_die_alu_core #(
        .DATA_WIDTH(8)
    ) u_alu (
        .operand_a    (alu_operand_a),
        .operand_b    (alu_operand_b),
        .opcode       (alu_opcode),
        .result       (alu_result),
        .zero_flag    (alu_zero_flag),
        .carry_flag   (alu_carry_flag),
        .overflow_flag(alu_overflow_flag)
    );

    rtl_bidirectional_dwr_candidate #(
        .WIDTH(8)
    ) u_dwr (
        .clk                (dwr_clk),
        .rst_n              (trst),
        .capture_enable     (dwr_capture_enable),
        .boundary_seq_mode  (dwr_boundary_seq_mode),
        .local_tx_core_value(alu_result),
        .d2d_rx             (sram_readout1_to_basic),
        .d2d_tx             (basic_to_sram_readout1),
        .local_rx_live      (remote_sram_readout_live),
        .rx_candidate_value (dwr_rx_candidate_value),
        .tx_candidate_value (dwr_tx_candidate_value)
    );

    rtl_readback_mux #(
        .WIDTH(8)
    ) u_readback_mux (
        .core_value   (alu_result),
        .seq_value    (dwr_rx_candidate_value),
        .seq_select   (readback_seq_select),
        .selected_data(alu_tdo_readback)
    );

    assign remote_sram_readout_snapshot = dwr_rx_candidate_value;

endmodule

