module top_sram_readout_die_temperature_dwr_top (
    input              tck,
    input              tms,
    input              tdi,
    output             tdo,
    input              trst,

    input              clk,
    input              rst_n,
    input        [7:0] sram_readout_temperature_code,

    input        [7:0] sram_readout1_to_sram_readout2,
    output       [7:0] sram_readout2_to_sram_readout1,

    output       [7:0] temperature_value,
    output             temperature_valid,
    output       [7:0] remote_alu_live,
    output       [7:0] remote_alu_snapshot
);

    wire       sample_enable;
    wire       readback_seq_select;
    wire       dwr_capture_enable;
    wire       dwr_boundary_seq_mode;
    wire [7:0] dwr_rx_candidate_value;
    wire [7:0] dwr_tx_candidate_value;
    wire [7:0] temperature_tdo_readback;

    upper_die_temperature_core #(
        .TEMP_WIDTH(8)
    ) u_temperature (
        .clk                    (clk),
        .rst_n                  (rst_n),
        .sample_enable          (sample_enable),
        .sram_readout_temperature_code(sram_readout_temperature_code),
        .temperature_value      (temperature_value),
        .temperature_valid      (temperature_valid)
    );

    rtl_bidirectional_dwr_candidate #(
        .WIDTH(8)
    ) u_dwr (
        .clk                (clk),
        .rst_n              (trst),
        .capture_enable     (dwr_capture_enable),
        .boundary_seq_mode  (dwr_boundary_seq_mode),
        .local_tx_core_value(temperature_value),
        .d2d_rx             (sram_readout1_to_sram_readout2),
        .d2d_tx             (sram_readout2_to_sram_readout1),
        .local_rx_live      (remote_alu_live),
        .rx_candidate_value (dwr_rx_candidate_value),
        .tx_candidate_value (dwr_tx_candidate_value)
    );

    rtl_readback_mux #(
        .WIDTH(8)
    ) u_readback_mux (
        .core_value   (temperature_value),
        .seq_value    (dwr_rx_candidate_value),
        .seq_select   (readback_seq_select),
        .selected_data(temperature_tdo_readback)
    );

    assign remote_alu_snapshot = dwr_rx_candidate_value;

endmodule

