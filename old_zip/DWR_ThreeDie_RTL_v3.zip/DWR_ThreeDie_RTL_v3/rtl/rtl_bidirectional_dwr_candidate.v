module rtl_bidirectional_dwr_candidate #(
    parameter WIDTH = 8
) (
    input                      clk,
    input                      rst_n,

    input                      capture_enable,
    input                      boundary_seq_mode,

    input      [WIDTH-1:0]     local_tx_core_value,
    input      [WIDTH-1:0]     d2d_rx,

    output     [WIDTH-1:0]     d2d_tx,
    output     [WIDTH-1:0]     local_rx_live,
    output     [WIDTH-1:0]     rx_candidate_value,
    output     [WIDTH-1:0]     tx_candidate_value
);

    /*
     * These are ordinary RTL flops placed at the die boundary.
     * They are intentionally named so that Synopsys DC constraints and
     * future Tessent wrapper analysis can locate them deterministically.
    */
    (* keep = "true", dont_touch = "true", syn_preserve = 1 *)
    reg [WIDTH-1:0] dwr_rx_candidate;

    (* keep = "true", dont_touch = "true", syn_preserve = 1 *)
    reg [WIDTH-1:0] dwr_tx_candidate;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            dwr_rx_candidate <= {WIDTH{1'b0}};
            dwr_tx_candidate <= {WIDTH{1'b0}};
        end else if (capture_enable) begin
            dwr_rx_candidate <= d2d_rx;
            dwr_tx_candidate <= local_tx_core_value;
        end
    end

    /*
     * Functional/core mode preserves the original zero-latency path.
     * Sequential boundary mode drives the inter-die bus from the stored
     * TX candidate flop value.
     */
    assign local_rx_live = d2d_rx;
    assign d2d_tx = boundary_seq_mode
                  ? dwr_tx_candidate
                  : local_tx_core_value;
    assign rx_candidate_value = dwr_rx_candidate;
    assign tx_candidate_value = dwr_tx_candidate;

endmodule
