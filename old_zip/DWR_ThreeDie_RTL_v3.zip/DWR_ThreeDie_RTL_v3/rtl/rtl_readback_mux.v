module rtl_readback_mux #(
    parameter WIDTH = 8
) (
    input  [WIDTH-1:0] core_value,
    input  [WIDTH-1:0] seq_value,
    input              seq_select,
    output [WIDTH-1:0] selected_data
);

    assign selected_data = seq_select ? seq_value : core_value;

endmodule
