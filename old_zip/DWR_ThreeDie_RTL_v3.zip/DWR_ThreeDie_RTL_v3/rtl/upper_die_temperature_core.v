module upper_die_temperature_core #(
    parameter TEMP_WIDTH = 8
) (
    input                        clk,
    input                        rst_n,

    input                        sample_enable,
    input      [TEMP_WIDTH-1:0] sram_readout_temperature_code,

    output reg [TEMP_WIDTH-1:0] temperature_value,
    output reg                  temperature_valid
);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            temperature_value <= {TEMP_WIDTH{1'b0}};
            temperature_valid <= 1'b0;
        end else if (sample_enable) begin
            temperature_value <= sram_readout_temperature_code;
            temperature_valid <= 1'b1;
        end
    end

endmodule
