# ============================================================
# Basic/bottom die: RTL DWR candidates + IEEE 1687 + IEEE 1838
#
# Resulting hierarchy:
#   HostScanInterface(tap)
#     Tap(main)
#       HostIjtag(1) -> Sib(alu) -> Tdr(alu_tdr)
#       HostStap(s1) -> middle SRAM Readout die
#
# HostIjtag and HostStap are deliberately declared in the same
# read_config_data block, matching the user's verified composition rule.
#
# This is an RTL DWR-candidate demonstrator.  It does not run:
#   analyze_wrapper_cells
#   analyze_scan_chains
#   insert_test_logic
# ============================================================

set script_dir    [file dirname [file normalize [info script]]]
set project_dir   [file dirname $script_dir]
set generated_dir ${project_dir}/generated_rtl
set output_dir    ${project_dir}/output/basic
set tsdb_dir      ${output_dir}/tsdb

file mkdir $generated_dir
file mkdir $output_dir
file mkdir $tsdb_dir

source ${script_dir}/generate_dwr_wrappers.tcl
generate_basic_die_dwr_wrapper \
    ${generated_dir}/basic_die_alu_dwr_top.v

set_context dft -rtl -design_id rtl_basic_three_die_dwr
set_tsdb_output_directory $tsdb_dir

# Optional only.  The script can use Tessent RTL cells when no .tcelllib
# is available; Synopsys DC performs the later technology mapping.
if {[info exists env(TESSENT_CELL_LIBRARY)] &&
    $env(TESSENT_CELL_LIBRARY) ne ""} {
    read_cell_library $env(TESSENT_CELL_LIBRARY)
}

read_verilog ${project_dir}/rtl/base_die_alu_core.v -format verilog2001
read_verilog ${project_dir}/rtl/rtl_bidirectional_dwr_candidate.v -format verilog2001
read_verilog ${project_dir}/rtl/rtl_readback_mux.v -format verilog2001
read_verilog ${generated_dir}/basic_die_alu_dwr_top.v -format verilog2001

set_current_design basic_die_alu_dwr_top
set_design_level chip

set_attribute_value tck  -name function -value tck
set_attribute_value tms  -name function -value tms
set_attribute_value tdi  -name function -value tdi
set_attribute_value tdo  -name function -value tdo
set_attribute_value trst -name function -value trst

add_clocks 0 dwr_clk -period 10ns
set_dft_specification_requirements -host_scan_interface_type tap
check_design_rules

set spec [create_dft_specification]

if {![info exists env(MAIN_TAP_CONFIG_PATH)] ||
    $env(MAIN_TAP_CONFIG_PATH) eq ""} {
    set main_tap_config_path \
        "IjtagNetwork/HostScanInterface(tap)/Tap(main)"
} else {
    set main_tap_config_path $env(MAIN_TAP_CONFIG_PATH)
}

set main_tap_path ${spec}/${main_tap_config_path}

if {[catch {report_config_data $main_tap_path} path_error]} {
    error "Cannot find main TAP path '$main_tap_config_path'. Copy the actual Tap(main) path from report_config_data and set MAIN_TAP_CONFIG_PATH. Tessent message: $path_error"
}

# No technology .tcelllib is required for this RTL-only first pass.
if {![info exists env(TESSENT_CELL_LIBRARY)] ||
    $env(TESSENT_CELL_LIBRARY) eq ""} {
    set_config_value -in $spec use_rtl_cells on
}

# ALU TDR bit map (33 bits):
#   [7:0]    operand_a
#   [15:8]   operand_b
#   [18:16]  opcode
#   [19]     readback_seq_select: 0=ALU COMB, 1=DWR RX FF
#   [20]     dwr_capture_enable
#   [21]     dwr_boundary_seq_mode: 0=direct core TX, 1=TX FF
#   [29:22]  selected readback data
#   [30]     zero flag
#   [31]     carry flag
#   [32]     overflow flag
read_config_data -in $main_tap_path -from_string {
    HostIjtag(1) {
        Sib(alu) {
            Tdr(alu_tdr) {
                length : 33;

                DataOutPorts {
                    connection(7:0)   : u_alu/operand_a[7:0];
                    connection(15:8)  : u_alu/operand_b[7:0];
                    connection(18:16) : u_alu/opcode[2:0];
                    connection(19)    : u_readback_mux/seq_select;
                    connection(20)    : u_dwr/capture_enable;
                    connection(21)    : u_dwr/boundary_seq_mode;
                }

                DataInPorts {
                    connection(29:22) : u_readback_mux/selected_data[7:0];
                    connection(30)    : u_alu/zero_flag;
                    connection(31)    : u_alu/carry_flag;
                    connection(32)    : u_alu/overflow_flag;
                }
            }
        }
    }

    HostStap(s1) {
    }
}

report_config_data $spec
process_dft_specification -validate_only
process_dft_specification
extract_icl

write_design -tsdb -verbose
write_design \
    -output_file ${output_dir}/basic_die_1687_1838_three_die_dwr_inserted.v \
    -replace

write_design_import_script \
    ${output_dir}/basic_die_dc_import.tcl \
    -replace \
    -use_relative_path_to $project_dir

puts "Basic/bottom die RTL DWR/1687/1838 insertion completed"
puts "Inserted RTL: ${output_dir}/basic_die_1687_1838_three_die_dwr_inserted.v"
puts "TSDB        : $tsdb_dir"
exit
