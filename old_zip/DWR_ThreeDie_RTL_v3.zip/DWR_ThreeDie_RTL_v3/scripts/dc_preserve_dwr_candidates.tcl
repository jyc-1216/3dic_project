# Source this after the Tessent-generated DC import script.

set dwr_candidate_cells [get_cells -hierarchical -quiet \
    *dwr_*_candidate_reg*]

if {[sizeof_collection $dwr_candidate_cells] == 0} {
    puts "WARNING: no DWR candidate register cells matched"
} else {
    set_dont_touch $dwr_candidate_cells true
    puts "Preserved [sizeof_collection $dwr_candidate_cells] DWR candidate cells"
}
