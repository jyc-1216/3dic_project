proc write_generated_rtl {output_file contents} {
    file mkdir [file dirname $output_file]
    set fh [open $output_file w]
    puts $fh $contents
    close $fh
    puts "Generated RTL: $output_file"
}

proc generate_basic_die_dwr_wrapper {output_file} {
    set contents {module basic_die_alu_dwr_top (
    input              tck,
    input              tms,
    input              tdi,
    output             tdo,
    input              trst,

    input              dwr_clk,

    output       [7:0] basic_to_sram_readout1,
    input        [7:0] sram_readout1_to_basic,

    output       [7:0] alu_operand_a,
    output       [7:0] alu_operand_b,
    output       [2:0] alu_opcode,
    output       [7:0] alu_result,
    output             alu_zero_flag,
    output             alu_carry_flag,
    output             alu_overflow_flag,

    output       [7:0] remote_sram_readout_live,
    output       [7:0] remote_sram_readout_snapshot
);

    wire       readback_seq_select;
    wire       dwr_capture_enable;
    wire       dwr_boundary_seq_mode;
    wire [7:0] dwr_rx_candidate_value;
    wire [7:0] dwr_tx_candidate_value;
    wire [7:0] alu_tdo_readback;

    base_die_alu_core #(
        .DATA_WIDTH(8)
    ) u_alu (
        .operand_a    (alu_operand_a),
        .operand_b    (alu_operand_b),
        .opcode       (alu_opcode),
        .result       (alu_result),
        .zero_flag    (alu_zero_flag),
        .carry_flag   (alu_carry_flag),
        .overflow_flag(alu_overflow_flag)
    );

    rtl_bidirectional_dwr_candidate #(
        .WIDTH(8)
    ) u_dwr (
        .clk                (dwr_clk),
        .rst_n              (trst),
        .capture_enable     (dwr_capture_enable),
        .boundary_seq_mode  (dwr_boundary_seq_mode),
        .local_tx_core_value(alu_result),
        .d2d_rx             (sram_readout1_to_basic),
        .d2d_tx             (basic_to_sram_readout1),
        .local_rx_live      (remote_sram_readout_live),
        .rx_candidate_value (dwr_rx_candidate_value),
        .tx_candidate_value (dwr_tx_candidate_value)
    );

    rtl_readback_mux #(
        .WIDTH(8)
    ) u_readback_mux (
        .core_value   (alu_result),
        .seq_value    (dwr_rx_candidate_value),
        .seq_select   (readback_seq_select),
        .selected_data(alu_tdo_readback)
    );

    assign remote_sram_readout_snapshot = dwr_rx_candidate_value;

endmodule
}

    write_generated_rtl $output_file $contents
}

proc generate_middle_sram_readout_die_dwr_wrapper {output_file} {
    set contents {module middle_sram_readout_die_temperature_dwr_top (
    input              tck,
    input              tms,
    input              tdi,
    output             tdo,
    input              trst,

    input              clk,
    input              rst_n,
    input        [7:0] sram_readout_temperature_code,

    input        [7:0] basic_to_sram_readout1,
    output       [7:0] sram_readout1_to_basic,

    output       [7:0] sram_readout1_to_sram_readout2,
    input        [7:0] sram_readout2_to_sram_readout1,

    output       [7:0] temperature_value,
    output             temperature_valid,
    output       [7:0] remote_alu_live,
    output       [7:0] remote_alu_snapshot,
    output       [7:0] remote_sram_readout2_live,
    output       [7:0] remote_sram_readout2_snapshot
);

    wire       sample_enable;
    wire       readback_seq_select;
    wire       readback_rx_side_select;
    wire       dwr_down_capture_enable;
    wire       dwr_up_capture_enable;
    wire       dwr_down_boundary_seq_mode;
    wire       dwr_up_boundary_seq_mode;
    wire       downlink_source_select;

    wire [7:0] down_rx_candidate_value;
    wire [7:0] down_tx_candidate_value;
    wire [7:0] up_rx_candidate_value;
    wire [7:0] up_tx_candidate_value;
    wire [7:0] downlink_core_value;
    wire [7:0] selected_seq_readback;
    wire [7:0] temperature_tdo_readback;

    upper_die_temperature_core #(
        .TEMP_WIDTH(8)
    ) u_temperature (
        .clk                    (clk),
        .rst_n                  (rst_n),
        .sample_enable          (sample_enable),
        .sram_readout_temperature_code(sram_readout_temperature_code),
        .temperature_value      (temperature_value),
        .temperature_valid      (temperature_valid)
    );

    /*
     * Down-facing interface:
     *   RX receives the ALU value from the Basic die.
     *   TX returns either SRAM Readout 1 temperature or forwarded SRAM Readout 2 data.
     */
    rtl_readback_mux #(
        .WIDTH(8)
    ) u_downlink_source_mux (
        .core_value   (temperature_value),
        .seq_value    (sram_readout2_to_sram_readout1),
        .seq_select   (downlink_source_select),
        .selected_data(downlink_core_value)
    );

    rtl_bidirectional_dwr_candidate #(
        .WIDTH(8)
    ) u_dwr_down (
        .clk                (clk),
        .rst_n              (trst),
        .capture_enable     (dwr_down_capture_enable),
        .boundary_seq_mode  (dwr_down_boundary_seq_mode),
        .local_tx_core_value(downlink_core_value),
        .d2d_rx             (basic_to_sram_readout1),
        .d2d_tx             (sram_readout1_to_basic),
        .local_rx_live      (remote_alu_live),
        .rx_candidate_value (down_rx_candidate_value),
        .tx_candidate_value (down_tx_candidate_value)
    );

    /*
     * Up-facing interface:
     *   TX forwards the Basic-die value to SRAM Readout 2.
     *   RX receives SRAM Readout 2 temperature data.
     */
    rtl_bidirectional_dwr_candidate #(
        .WIDTH(8)
    ) u_dwr_up (
        .clk                (clk),
        .rst_n              (trst),
        .capture_enable     (dwr_up_capture_enable),
        .boundary_seq_mode  (dwr_up_boundary_seq_mode),
        .local_tx_core_value(basic_to_sram_readout1),
        .d2d_rx             (sram_readout2_to_sram_readout1),
        .d2d_tx             (sram_readout1_to_sram_readout2),
        .local_rx_live      (remote_sram_readout2_live),
        .rx_candidate_value (up_rx_candidate_value),
        .tx_candidate_value (up_tx_candidate_value)
    );

    rtl_readback_mux #(
        .WIDTH(8)
    ) u_seq_side_mux (
        .core_value   (down_rx_candidate_value),
        .seq_value    (up_rx_candidate_value),
        .seq_select   (readback_rx_side_select),
        .selected_data(selected_seq_readback)
    );

    rtl_readback_mux #(
        .WIDTH(8)
    ) u_readback_mux (
        .core_value   (temperature_value),
        .seq_value    (selected_seq_readback),
        .seq_select   (readback_seq_select),
        .selected_data(temperature_tdo_readback)
    );

    assign remote_alu_snapshot     = down_rx_candidate_value;
    assign remote_sram_readout2_snapshot = up_rx_candidate_value;

endmodule
}

    write_generated_rtl $output_file $contents
}

proc generate_top_sram_readout_die_dwr_wrapper {output_file} {
    set contents {module top_sram_readout_die_temperature_dwr_top (
    input              tck,
    input              tms,
    input              tdi,
    output             tdo,
    input              trst,

    input              clk,
    input              rst_n,
    input        [7:0] sram_readout_temperature_code,

    input        [7:0] sram_readout1_to_sram_readout2,
    output       [7:0] sram_readout2_to_sram_readout1,

    output       [7:0] temperature_value,
    output             temperature_valid,
    output       [7:0] remote_alu_live,
    output       [7:0] remote_alu_snapshot
);

    wire       sample_enable;
    wire       readback_seq_select;
    wire       dwr_capture_enable;
    wire       dwr_boundary_seq_mode;
    wire [7:0] dwr_rx_candidate_value;
    wire [7:0] dwr_tx_candidate_value;
    wire [7:0] temperature_tdo_readback;

    upper_die_temperature_core #(
        .TEMP_WIDTH(8)
    ) u_temperature (
        .clk                    (clk),
        .rst_n                  (rst_n),
        .sample_enable          (sample_enable),
        .sram_readout_temperature_code(sram_readout_temperature_code),
        .temperature_value      (temperature_value),
        .temperature_valid      (temperature_valid)
    );

    rtl_bidirectional_dwr_candidate #(
        .WIDTH(8)
    ) u_dwr (
        .clk                (clk),
        .rst_n              (trst),
        .capture_enable     (dwr_capture_enable),
        .boundary_seq_mode  (dwr_boundary_seq_mode),
        .local_tx_core_value(temperature_value),
        .d2d_rx             (sram_readout1_to_sram_readout2),
        .d2d_tx             (sram_readout2_to_sram_readout1),
        .local_rx_live      (remote_alu_live),
        .rx_candidate_value (dwr_rx_candidate_value),
        .tx_candidate_value (dwr_tx_candidate_value)
    );

    rtl_readback_mux #(
        .WIDTH(8)
    ) u_readback_mux (
        .core_value   (temperature_value),
        .seq_value    (dwr_rx_candidate_value),
        .seq_select   (readback_seq_select),
        .selected_data(temperature_tdo_readback)
    );

    assign remote_alu_snapshot = dwr_rx_candidate_value;

endmodule
}

    write_generated_rtl $output_file $contents
}

if {[file normalize [info script]] eq [file normalize $argv0]} {
    if {[llength $argv] > 0} {
        set output_dir [file normalize [lindex $argv 0]]
    } else {
        set script_dir [file dirname [file normalize [info script]]]
        set output_dir [file normalize ${script_dir}/../generated_rtl]
    }

    generate_basic_die_dwr_wrapper \
        ${output_dir}/basic_die_alu_dwr_top.v

    generate_middle_sram_readout_die_dwr_wrapper \
        ${output_dir}/middle_sram_readout_die_temperature_dwr_top.v

    generate_top_sram_readout_die_dwr_wrapper \
        ${output_dir}/top_sram_readout_die_temperature_dwr_top.v
}
