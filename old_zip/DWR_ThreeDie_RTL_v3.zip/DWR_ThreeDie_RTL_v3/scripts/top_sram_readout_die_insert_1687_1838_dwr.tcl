# ============================================================
# Top SRAM Readout die: one RTL DWR boundary + IEEE 1687/1838 PTAP
#
# Top-most die rule:
#   HostIjtag(1) is present.
#   HostStap is absent because no die exists above this die.
# ============================================================

set script_dir    [file dirname [file normalize [info script]]]
set project_dir   [file dirname $script_dir]
set generated_dir ${project_dir}/generated_rtl
set output_dir    ${project_dir}/output/sram_readout_top
set tsdb_dir      ${output_dir}/tsdb

file mkdir $generated_dir
file mkdir $output_dir
file mkdir $tsdb_dir

source ${script_dir}/generate_dwr_wrappers.tcl
generate_top_sram_readout_die_dwr_wrapper \
    ${generated_dir}/top_sram_readout_die_temperature_dwr_top.v

set_context dft -rtl -design_id rtl_top_sram_readout_three_die_dwr
set_tsdb_output_directory $tsdb_dir

if {[info exists env(TESSENT_CELL_LIBRARY)] &&
    $env(TESSENT_CELL_LIBRARY) ne ""} {
    read_cell_library $env(TESSENT_CELL_LIBRARY)
}

read_verilog ${project_dir}/rtl/upper_die_temperature_core.v -format verilog2001
read_verilog ${project_dir}/rtl/rtl_bidirectional_dwr_candidate.v -format verilog2001
read_verilog ${project_dir}/rtl/rtl_readback_mux.v -format verilog2001
read_verilog ${generated_dir}/top_sram_readout_die_temperature_dwr_top.v -format verilog2001

set_current_design top_sram_readout_die_temperature_dwr_top
set_design_level chip

set_attribute_value tck  -name function -value tck
set_attribute_value tms  -name function -value tms
set_attribute_value tdi  -name function -value tdi
set_attribute_value tdo  -name function -value tdo
set_attribute_value trst -name function -value trst

add_clocks 0 clk -period 10ns
set_dft_specification_requirements -host_scan_interface_type tap
check_design_rules

set spec [create_dft_specification]

if {![info exists env(MAIN_TAP_CONFIG_PATH)] ||
    $env(MAIN_TAP_CONFIG_PATH) eq ""} {
    set main_tap_config_path \
        "IjtagNetwork/HostScanInterface(tap)/Tap(main)"
} else {
    set main_tap_config_path $env(MAIN_TAP_CONFIG_PATH)
}

set main_tap_path ${spec}/${main_tap_config_path}

if {[catch {report_config_data $main_tap_path} path_error]} {
    error "Cannot find main TAP path '$main_tap_config_path'. Copy the actual Tap(main) path from report_config_data and set MAIN_TAP_CONFIG_PATH. Tessent message: $path_error"
}

if {![info exists env(TESSENT_CELL_LIBRARY)] ||
    $env(TESSENT_CELL_LIBRARY) eq ""} {
    set_config_value -in $spec use_rtl_cells on
}

# Top SRAM Readout TDR bit map (13 bits):
#   [7:0]   selected readback data
#   [8]     temperature_valid
#   [9]     sample_enable
#   [10]    0=local temperature, 1=down-facing RX candidate
#   [11]    DWR capture
#   [12]    boundary mode: 0=temperature CORE, 1=TX FF
read_config_data -in $main_tap_path -from_string {
    HostIjtag(1) {
        Sib(temperature_top) {
            Tdr(temperature_top_tdr) {
                length : 13;

                DataOutPorts {
                    connection(9)  : u_temperature/sample_enable;
                    connection(10) : u_readback_mux/seq_select;
                    connection(11) : u_dwr/capture_enable;
                    connection(12) : u_dwr/boundary_seq_mode;
                }

                DataInPorts {
                    connection(7:0) : u_readback_mux/selected_data[7:0];
                    connection(8)   : u_temperature/temperature_valid;
                }
            }
        }
    }
}

report_config_data $spec
process_dft_specification -validate_only
process_dft_specification
extract_icl

write_design -tsdb -verbose
write_design \
    -output_file ${output_dir}/top_sram_readout_die_1687_1838_dwr_inserted.v \
    -replace

write_design_import_script \
    ${output_dir}/top_sram_readout_die_dc_import.tcl \
    -replace \
    -use_relative_path_to $project_dir

puts "Top SRAM Readout die RTL DWR/1687/1838 insertion completed"
puts "Inserted RTL: ${output_dir}/top_sram_readout_die_1687_1838_dwr_inserted.v"
puts "TSDB        : $tsdb_dir"
exit
