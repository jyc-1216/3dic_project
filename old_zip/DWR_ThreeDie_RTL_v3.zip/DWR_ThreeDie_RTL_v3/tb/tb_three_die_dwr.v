`timescale 1ns/1ps

module tb_three_die_dwr;

    reg       clk;
    reg       rst_n;
    reg       capture_enable;
    reg       boundary_seq_mode;
    reg       sram_readout1_downlink_source_select;

    reg [7:0] alu_core_value;
    reg [7:0] sram_readout1_core_value;
    reg [7:0] sram_readout2_core_value;

    wire [7:0] basic_to_sram_readout1;
    wire [7:0] sram_readout1_to_basic;
    wire [7:0] sram_readout1_to_sram_readout2;
    wire [7:0] sram_readout2_to_sram_readout1;

    wire [7:0] basic_rx_live;
    wire [7:0] basic_rx_snapshot;
    wire [7:0] basic_tx_snapshot;

    wire [7:0] sram_readout1_down_rx_live;
    wire [7:0] sram_readout1_down_rx_snapshot;
    wire [7:0] sram_readout1_down_tx_snapshot;
    wire [7:0] sram_readout1_up_rx_live;
    wire [7:0] sram_readout1_up_rx_snapshot;
    wire [7:0] sram_readout1_up_tx_snapshot;

    wire [7:0] sram_readout2_rx_live;
    wire [7:0] sram_readout2_rx_snapshot;
    wire [7:0] sram_readout2_tx_snapshot;

    wire [7:0] sram_readout1_downlink_core_value;
    reg        readback_seq_select;
    reg        readback_rx_side_select;
    wire [7:0] sram_readout1_selected_seq;
    wire [7:0] sram_readout1_selected_readback;

    task fail;
        input [8*128-1:0] message;
        begin
            $display("FAIL: %s", message);
            $finish;
        end
    endtask

    always #5 clk = ~clk;

    assign sram_readout1_downlink_core_value =
        sram_readout1_downlink_source_select ? sram_readout2_to_sram_readout1
                                       : sram_readout1_core_value;

    rtl_bidirectional_dwr_candidate #(
        .WIDTH(8)
    ) u_basic_dwr (
        .clk                (clk),
        .rst_n              (rst_n),
        .capture_enable     (capture_enable),
        .boundary_seq_mode  (boundary_seq_mode),
        .local_tx_core_value(alu_core_value),
        .d2d_rx             (sram_readout1_to_basic),
        .d2d_tx             (basic_to_sram_readout1),
        .local_rx_live      (basic_rx_live),
        .rx_candidate_value (basic_rx_snapshot),
        .tx_candidate_value (basic_tx_snapshot)
    );

    rtl_bidirectional_dwr_candidate #(
        .WIDTH(8)
    ) u_sram_readout1_down_dwr (
        .clk                (clk),
        .rst_n              (rst_n),
        .capture_enable     (capture_enable),
        .boundary_seq_mode  (boundary_seq_mode),
        .local_tx_core_value(sram_readout1_downlink_core_value),
        .d2d_rx             (basic_to_sram_readout1),
        .d2d_tx             (sram_readout1_to_basic),
        .local_rx_live      (sram_readout1_down_rx_live),
        .rx_candidate_value (sram_readout1_down_rx_snapshot),
        .tx_candidate_value (sram_readout1_down_tx_snapshot)
    );

    rtl_bidirectional_dwr_candidate #(
        .WIDTH(8)
    ) u_sram_readout1_up_dwr (
        .clk                (clk),
        .rst_n              (rst_n),
        .capture_enable     (capture_enable),
        .boundary_seq_mode  (boundary_seq_mode),
        .local_tx_core_value(basic_to_sram_readout1),
        .d2d_rx             (sram_readout2_to_sram_readout1),
        .d2d_tx             (sram_readout1_to_sram_readout2),
        .local_rx_live      (sram_readout1_up_rx_live),
        .rx_candidate_value (sram_readout1_up_rx_snapshot),
        .tx_candidate_value (sram_readout1_up_tx_snapshot)
    );

    rtl_bidirectional_dwr_candidate #(
        .WIDTH(8)
    ) u_sram_readout2_dwr (
        .clk                (clk),
        .rst_n              (rst_n),
        .capture_enable     (capture_enable),
        .boundary_seq_mode  (boundary_seq_mode),
        .local_tx_core_value(sram_readout2_core_value),
        .d2d_rx             (sram_readout1_to_sram_readout2),
        .d2d_tx             (sram_readout2_to_sram_readout1),
        .local_rx_live      (sram_readout2_rx_live),
        .rx_candidate_value (sram_readout2_rx_snapshot),
        .tx_candidate_value (sram_readout2_tx_snapshot)
    );

    rtl_readback_mux #(
        .WIDTH(8)
    ) u_sram_readout1_seq_side_mux (
        .core_value   (sram_readout1_down_rx_snapshot),
        .seq_value    (sram_readout1_up_rx_snapshot),
        .seq_select   (readback_rx_side_select),
        .selected_data(sram_readout1_selected_seq)
    );

    rtl_readback_mux #(
        .WIDTH(8)
    ) u_sram_readout1_readback_mux (
        .core_value   (sram_readout1_core_value),
        .seq_value    (sram_readout1_selected_seq),
        .seq_select   (readback_seq_select),
        .selected_data(sram_readout1_selected_readback)
    );

    initial begin
        clk                            = 1'b0;
        rst_n                          = 1'b0;
        capture_enable                 = 1'b0;
        boundary_seq_mode              = 1'b0;
        sram_readout1_downlink_source_select = 1'b0;
        readback_seq_select             = 1'b0;
        readback_rx_side_select         = 1'b0;
        alu_core_value                  = 8'hA5;
        sram_readout1_core_value              = 8'h69;
        sram_readout2_core_value              = 8'h3C;

        repeat (2) @(posedge clk);
        rst_n = 1'b1;
        #1;

        if (basic_to_sram_readout1 !== 8'hA5)
            fail("Basic-to-SRAM Readout1 functional path failed");
        if (sram_readout1_to_sram_readout2 !== 8'hA5)
            fail("SRAM Readout1 did not forward the ALU value to SRAM Readout2");
        if (sram_readout2_rx_live !== 8'hA5)
            fail("SRAM Readout2 did not receive the forwarded ALU value");

        if (sram_readout1_to_basic !== 8'h69)
            fail("SRAM Readout1 local temperature downlink failed");
        if (basic_rx_live !== 8'h69)
            fail("Basic die did not receive SRAM Readout1 temperature");

        sram_readout1_downlink_source_select = 1'b1;
        #1;
        if (sram_readout1_to_basic !== 8'h3C)
            fail("SRAM Readout1 did not forward SRAM Readout2 temperature downward");
        if (basic_rx_live !== 8'h3C)
            fail("Basic die did not receive SRAM Readout2 temperature");

        capture_enable = 1'b1;
        @(posedge clk);
        #1;
        capture_enable = 1'b0;

        if (basic_rx_snapshot !== 8'h3C)
            fail("Basic RX candidate capture failed");
        if (sram_readout1_down_rx_snapshot !== 8'hA5)
            fail("SRAM Readout1 down-facing RX capture failed");
        if (sram_readout1_up_rx_snapshot !== 8'h3C)
            fail("SRAM Readout1 up-facing RX capture failed");
        if (sram_readout2_rx_snapshot !== 8'hA5)
            fail("SRAM Readout2 RX candidate capture failed");

        alu_core_value     = 8'h5A;
        sram_readout1_core_value = 8'h96;
        sram_readout2_core_value = 8'hC3;
        boundary_seq_mode  = 1'b1;
        #1;

        if (basic_to_sram_readout1 !== 8'hA5)
            fail("Basic stored TX boundary value failed");
        if (sram_readout1_to_sram_readout2 !== 8'hA5)
            fail("SRAM Readout1 stored upward TX value failed");
        if (sram_readout2_to_sram_readout1 !== 8'h3C)
            fail("SRAM Readout2 stored TX boundary value failed");
        if (sram_readout1_to_basic !== 8'h3C)
            fail("SRAM Readout1 stored downward TX value failed");

        readback_seq_select = 1'b0;
        #1;
        if (sram_readout1_selected_readback !== 8'h96)
            fail("SRAM Readout1 CORE readback selection failed");

        readback_seq_select     = 1'b1;
        readback_rx_side_select = 1'b0;
        #1;
        if (sram_readout1_selected_readback !== 8'hA5)
            fail("SRAM Readout1 down-facing SEQ readback failed");

        readback_rx_side_select = 1'b1;
        #1;
        if (sram_readout1_selected_readback !== 8'h3C)
            fail("SRAM Readout1 up-facing SEQ readback failed");

        $display("PASS: three-die bidirectional DWR forwarding and CORE/SEQ readback");
        $finish;
    end

endmodule
