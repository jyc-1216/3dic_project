# Tessent Multi-die capability smoke test
#
# Usage:
#   DESIGN_TOP=basic_die_top \
#   RTL_FILES="/abs/basic_die_alu_core.v /abs/basic_die_top.v" \
#   SMOKE_TSDB=/abs/tsdb_multidie_smoke \
#   tessent -shell -dofile 00_check_multidie_capability.tcl
#
# A successful `help` query only proves command availability.  Successful
# process_dft_specification is the authoritative checkout/insertion test.

foreach required_env {DESIGN_TOP RTL_FILES SMOKE_TSDB} {
    if {![info exists env($required_env)] || $env($required_env) eq ""} {
        error "Required environment variable $required_env is not set"
    }
}

set tsdb_dir [file normalize $env(SMOKE_TSDB)]
file mkdir $tsdb_dir

puts "Checking create_dft_specification command options"
help create_dft_specification

set_context dft -rtl -design_id multidie_capability_smoke
set_tsdb_output_directory $tsdb_dir

foreach rtl_file $env(RTL_FILES) {
    if {![file exists $rtl_file]} {
        error "Missing RTL file: $rtl_file"
    }
    read_verilog $rtl_file
}

set_current_design $env(DESIGN_TOP)
set_design_level chip

# Override these five names in a local copy if the design uses other names.
foreach {port function_name} {
    tck  tck
    tms  tms
    tdi  tdi
    tdo  tdo
    trst trst
} {
    set_attribute_value $port -name function -value $function_name
}

set_dft_specification_requirements -host_scan_interface_type tap
check_design_rules

# The documented Tessent Multi-die switch.  This requests one hosted STAP.
set spec [create_dft_specification -stap_host_list [list s1]]
report_config_data $spec
process_dft_specification
extract_icl
write_design -tsdb -verbose

puts "PASS: Multi-die insertion completed and TSDB was written to $tsdb_dir"
exit

