# ============================================================
# Basic-die Tessent RTL IJTAG / IEEE 1838 insertion flow
#
# Baseline IJTAG verification:
#   FLOW_MODE=baseline tessent -shell \
#       -dofile scripts/basic_die_insert_ijtag_1838.tcl
#
# Final IEEE 1838 die implementation:
#   FLOW_MODE=ieee1838 tessent -shell \
#       -dofile scripts/basic_die_insert_ijtag_1838.tcl
#
# Both modes start from the same golden Verilog-2001 RTL and reuse the
# same ALU SIB/TDR definition.  The ieee1838 mode additionally asks
# Tessent Multi-die to insert STAP s1 and enhance the TAP for 3D access.
# ============================================================

set script_dir  [file dirname [file normalize [info script]]]
set project_dir [file dirname $script_dir]

# Require an explicit mode so a baseline result cannot be mistaken for
# the final IEEE 1838 implementation.
if {![info exists env(FLOW_MODE)] || $env(FLOW_MODE) eq ""} {
    error "Set FLOW_MODE to baseline or ieee1838"
}

set flow_mode [string tolower $env(FLOW_MODE)]

switch -- $flow_mode {
    baseline {
        set design_id     rtl_ijtag_baseline
        set tsdb_dir      ${project_dir}/tsdb_basic_baseline
        set inserted_rtl  ${project_dir}/generated/basic_die_ijtag_inserted.v
        set dc_import_tcl ${project_dir}/generated/basic_die_ijtag_dc_import.tcl
    }
    ieee1838 {
        set design_id     rtl_1838_final
        set tsdb_dir      ${project_dir}/tsdb_basic_1838
        set inserted_rtl  ${project_dir}/generated/basic_die_1838_inserted.v
        set dc_import_tcl ${project_dir}/generated/basic_die_1838_dc_import.tcl
    }
    default {
        error "Unsupported FLOW_MODE '$flow_mode'; use baseline or ieee1838"
    }
}

set generated_dir ${project_dir}/generated
set log_dir       ${project_dir}/logs/${flow_mode}

file mkdir $generated_dir
file mkdir $tsdb_dir
file mkdir $log_dir

# Golden Verilog-2001 RTL.  Do not replace these paths with a previously
# IJTAG-inserted RTL file, or the TAP/SIB/TDR network may be duplicated.
set alu_rtl ${project_dir}/basic_die_alu_core.v
set top_rtl ${project_dir}/basic_die_top.v

foreach rtl_file [list $alu_rtl $top_rtl] {
    if {![file exists $rtl_file]} {
        error "Missing golden RTL file: $rtl_file"
    }
}

# No Tessent .tcelllib is used here.  Technology mapping is performed
# later in Synopsys Design Compiler using the process .db libraries.
set_context dft -rtl -design_id $design_id
set_tsdb_output_directory $tsdb_dir

read_verilog $alu_rtl
read_verilog $top_rtl

set_current_design basic_die_top
set_design_level chip

# Identify the external IEEE 1149.1 / IEEE 1838 serial test pins.
set_attribute_value tck  -name function -value tck
set_attribute_value tms  -name function -value tms
set_attribute_value tdi  -name function -value tdi
set_attribute_value tdo  -name function -value tdo
set_attribute_value trst -name function -value trst

set_dft_specification_requirements -host_scan_interface_type tap
check_design_rules

if {$flow_mode eq "ieee1838"} {
    # Tessent Multi-die 2024.4 documented flow:
    # Basic die is the bottom/base die and hosts one STAP for Sensor die.
    set spec [create_dft_specification \
        -stap_host_list [list s1]]
} else {
    # Standalone IJTAG baseline: ordinary TAP, no STAP/3DCR extension.
    set spec [create_dft_specification]
}

# The ALU instrument definition is intentionally identical in both modes.
read_config_data -in $spec -from_string {
    IjtagNetwork {
        HostScanInterface(ijtag) {
            Interface {
                tck : tck;
            }

            Tap(single) {
                HostIjtag(1) {
                    Sib(alu) {
                        Tdr(alu_tdr) {
                            length : 30;

                            DataOutPorts {
                                connection(7:0)   : u_alu/operand_a[7:0];
                                connection(15:8)  : u_alu/operand_b[7:0];
                                connection(18:16) : u_alu/opcode[2:0];
                            }

                            DataInPorts {
                                connection(26:19) : u_alu/result[7:0];
                                connection(27)    : u_alu/zero_flag;
                                connection(28)    : u_alu/carry_flag;
                                connection(29)    : u_alu/overflow_flag;
                            }
                        }
                    }
                }
            }
        }
    }
}

report_config_data $spec
process_dft_specification
extract_icl

# Store ICL, consolidated PDL, DFT metadata, and the inserted design in a
# mode-specific TSDB so baseline and IEEE 1838 results cannot overwrite
# or contaminate each other.
puts "Saving $design_id design view into TSDB: $tsdb_dir"
write_design -tsdb -verbose

puts "Writing post-DFT RTL: $inserted_rtl"
write_design \
    -output_file $inserted_rtl \
    -replace

# DC must source this generated import script.  Do not additionally read
# the human-readable inserted RTL in the same DC session.
puts "Writing Synopsys DC import script: $dc_import_tcl"
write_design_import_script \
    $dc_import_tcl \
    -replace \
    -use_relative_path_to $project_dir

puts "Basic-die insertion completed"
puts "FLOW_MODE    : $flow_mode"
puts "Design ID    : $design_id"
puts "Inserted RTL : $inserted_rtl"
puts "DC import Tcl: $dc_import_tcl"
puts "TSDB         : $tsdb_dir"
exit

