# Sensor-die Tessent RTL IJTAG / IEEE 1838 insertion flow
#
#   FLOW_MODE=baseline tessent -shell -dofile 02_sensor_die_insert_ijtag_1838.tcl
#   FLOW_MODE=ieee1838 tessent -shell -dofile 02_sensor_die_insert_ijtag_1838.tcl
#
# Sensor is the top-most die in the current two-die example.  Therefore its
# final mode does not request -stap_host_list.  If this die becomes reusable
# below another die, change the topology deliberately; never leave an STAP
# serial return path floating.

set script_dir  [file dirname [file normalize [info script]]]
set project_dir [file dirname $script_dir]

if {![info exists env(FLOW_MODE)] || $env(FLOW_MODE) eq ""} {
    error "Set FLOW_MODE to baseline or ieee1838"
}
set flow_mode [string tolower $env(FLOW_MODE)]

switch -- $flow_mode {
    baseline {
        set design_id     rtl_ijtag_baseline
        set tsdb_dir      ${project_dir}/tsdb_sensor_baseline
        set inserted_rtl  ${project_dir}/generated/sensor_die_ijtag_inserted.v
        set dc_import_tcl ${project_dir}/generated/sensor_die_ijtag_dc_import.tcl
    }
    ieee1838 {
        set design_id     rtl_1838_final
        set tsdb_dir      ${project_dir}/tsdb_sensor_1838
        set inserted_rtl  ${project_dir}/generated/sensor_die_1838_inserted.v
        set dc_import_tcl ${project_dir}/generated/sensor_die_1838_dc_import.tcl
    }
    default {
        error "Unsupported FLOW_MODE '$flow_mode'; use baseline or ieee1838"
    }
}

file mkdir ${project_dir}/generated
file mkdir $tsdb_dir
file mkdir ${project_dir}/logs/${flow_mode}

set core_rtl ${project_dir}/sensor_die_temperature_core.v
set top_rtl  ${project_dir}/sensor_die_top.v
foreach rtl_file [list $core_rtl $top_rtl] {
    if {![file exists $rtl_file]} {
        error "Missing golden RTL file: $rtl_file"
    }
}

# No Tessent .tcelllib is required for this RTL insertion.  Synopsys DC maps
# the generated RTL with the site's process .db libraries later.
set_context dft -rtl -design_id $design_id
set_tsdb_output_directory $tsdb_dir
read_verilog $core_rtl
read_verilog $top_rtl
set_current_design sensor_die_top
set_design_level chip

set_attribute_value tck  -name function -value tck
set_attribute_value tms  -name function -value tms
set_attribute_value tdi  -name function -value tdi
set_attribute_value tdo  -name function -value tdo
set_attribute_value trst -name function -value trst

set_dft_specification_requirements -host_scan_interface_type tap
check_design_rules

# Top-most die: no downstream STAP is needed in either mode.  Separate mode
# names/TSDBs still preserve the recursive baseline/final verification record.
set spec [create_dft_specification]

read_config_data -in $spec -from_string {
    IjtagNetwork {
        HostScanInterface(ijtag) {
            Interface { tck : tck; }
            Tap(single) {
                HostIjtag(1) {
                    Sib(temperature) {
                        Tdr(temperature_tdr) {
                            length : 10;
                            DataOutPorts {
                                connection(9) : u_temperature/sample_enable;
                            }
                            DataInPorts {
                                connection(7:0) : u_temperature/temperature_value[7:0];
                                connection(8)   : u_temperature/temperature_valid;
                            }
                        }
                    }
                }
            }
        }
    }
}

report_config_data $spec
process_dft_specification
extract_icl
write_design -tsdb -verbose
write_design -output_file $inserted_rtl -replace
write_design_import_script $dc_import_tcl -replace -use_relative_path_to $project_dir

puts "Sensor-die insertion completed"
puts "FLOW_MODE    : $flow_mode"
puts "Inserted RTL : $inserted_rtl"
puts "DC import Tcl: $dc_import_tcl"
puts "TSDB         : $tsdb_dir"
exit

