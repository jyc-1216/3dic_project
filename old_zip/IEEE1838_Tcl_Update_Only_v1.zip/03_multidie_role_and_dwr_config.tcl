# Shared IEEE 1838 role and DWR policy configuration.
# Source this file from site-specific die flows after setting DIE_ROLE.

if {![info exists DIE_ROLE]} {
    error "Set DIE_ROLE to bottom, middle, or top before sourcing this file"
}
set DIE_ROLE [string tolower $DIE_ROLE]

switch -- $DIE_ROLE {
    bottom {
        # One downstream die in the two-die reference stack.
        set STAP_HOST_LIST [list s1]
    }
    middle {
        # Safe one-downstream default.  Expand only from the real stack topology.
        set STAP_HOST_LIST [list s1]
    }
    top {
        # Tessent Multi-die guidance: top-most die does not need an STAP.
        set STAP_HOST_LIST [list]
    }
    default {
        error "Invalid DIE_ROLE '$DIE_ROLE'; expected bottom, middle, or top"
    }
}

# Team policy: die-to-die interconnect test is required unless explicitly
# disabled by an approved flow owner.
if {![info exists REQUIRE_DWR]} {
    set REQUIRE_DWR 1
}

# These values are intentionally not guessed.  Put the protected site-specific
# values in a local config file that sources this public template.
if {![info exists DIE_TO_DIE_PORTS]}  { set DIE_TO_DIE_PORTS [list] }
if {![info exists CHILD_BLOCKS]}      { set CHILD_BLOCKS [list] }
if {![info exists INT_EDT_INSTANCE]}  { set INT_EDT_INSTANCE "" }
if {![info exists EXT_EDT_INSTANCE]}  { set EXT_EDT_INSTANCE "" }

if {$REQUIRE_DWR && [llength $DIE_TO_DIE_PORTS] == 0} {
    error "DWR is required, but DIE_TO_DIE_PORTS is empty"
}

puts "DIE_ROLE       : $DIE_ROLE"
puts "STAP hosts     : $STAP_HOST_LIST"
puts "REQUIRE_DWR    : $REQUIRE_DWR"
puts "D2D port count : [llength $DIE_TO_DIE_PORTS]"

