# Gate-level DWR / scan insertion template for Tessent Multi-die.
#
# This is intentionally fail-closed.  It is not runnable until the real
# die-to-die ports, child physical blocks, and EDT instances are supplied.
# Source 03_multidie_role_and_dwr_config.tcl first in the same Tcl scope.

foreach required_var {
    REQUIRE_DWR DIE_TO_DIE_PORTS CHILD_BLOCKS INT_EDT_INSTANCE EXT_EDT_INSTANCE
} {
    if {![info exists $required_var]} {
        error "Missing configuration variable $required_var"
    }
}

if {!$REQUIRE_DWR} {
    puts "DWR disabled by approved configuration; no DWR/scan changes made"
    return
}
if {[llength $DIE_TO_DIE_PORTS] == 0} {
    error "DWR required but DIE_TO_DIE_PORTS is empty"
}
if {[llength $CHILD_BLOCKS] == 0} {
    error "DWR required but CHILD_BLOCKS is empty"
}
if {$INT_EDT_INSTANCE eq "" || $EXT_EDT_INSTANCE eq ""} {
    error "Both INT_EDT_INSTANCE and EXT_EDT_INSTANCE are required"
}

set d2d_ports [get_ports $DIE_TO_DIE_PORTS]
if {[sizeof_collection $d2d_ports] != [llength $DIE_TO_DIE_PORTS]} {
    error "At least one DIE_TO_DIE_PORTS entry did not resolve in the gate design"
}

# Promote only the flops interacting with die-to-die top ports to shared
# wrapper cells.  Keep all other top-level ports outside this DWR policy.
set non_d2d_ports [remove_from_collection [get_ports] $d2d_ports]
set_wrapper_analysis_options -exclude_ports $non_d2d_ports
set_dedicated_wrapper_cell_options off -ports $d2d_ports

# Internal die mode: child blocks expose their external scan mode.
set_attribute_value $CHILD_BLOCKS \
    -name active_child_scan_mode -value ext_edt_mode
check_design_rules
analyze_wrapper_cells
add_scan_mode int_edt_mode -edt_instance $INT_EDT_INSTANCE

# External die mode: used later for package die-to-die interconnect test.
set_attribute_value $CHILD_BLOCKS \
    -name active_child_scan_mode -value parent_ext_edt_mode
add_scan_mode ext_edt_mode \
    -edt_instance $EXT_EDT_INSTANCE \
    -include_elements [get_scan_elements *occ*] \
    -associate_chains [get_scan_elements -type chain]

analyze_scan_chains
insert_test_logic

puts "DWR/scan insertion completed; review wrapper and scan reports before signoff"

