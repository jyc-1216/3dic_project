# Wiring-only two-die stack ICL integration template.
#
# Required environment variables:
#   STACK_TOP, STACK_NETLIST, BASIC_DESIGN, SENSOR_DESIGN,
#   BASIC_TSDB, SENSOR_TSDB, STACK_TSDB
#
# STACK_NETLIST must describe only the actual package/die wiring.  Do not
# reinsert PTAP/STAP/DWR in this step; those structures belong inside each die.

foreach required_env {
    STACK_TOP STACK_NETLIST BASIC_DESIGN SENSOR_DESIGN
    BASIC_TSDB SENSOR_TSDB STACK_TSDB
} {
    if {![info exists env($required_env)] || $env($required_env) eq ""} {
        error "Required environment variable $required_env is not set"
    }
}
if {![file exists $env(STACK_NETLIST)]} {
    error "Missing stack wiring netlist: $env(STACK_NETLIST)"
}

set_context dft -rtl -design_id stack_icl_integration
set_tsdb_output_directory [file normalize $env(STACK_TSDB)]

# Import the two independently verified die TSDBs, then load their final gate
# interface views together with child ICL/PDL.
open_tsdb [file normalize $env(BASIC_TSDB)]
open_tsdb [file normalize $env(SENSOR_TSDB)]
read_verilog $env(STACK_NETLIST)
read_design $env(BASIC_DESIGN) \
    -design_id gate -view interface -include_child_blocks_icl_and_pdl
read_design $env(SENSOR_DESIGN) \
    -design_id gate -view interface -include_child_blocks_icl_and_pdl

set_current_design $env(STACK_TOP)
set_design_level chip

# Optional list of upward-facing pins left physically floating on the top die.
# Example value: "u_sensor/*_up".  Excluding these is documented for stack ICL.
if {[info exists env(FLOATING_UP_PINS)] && $env(FLOATING_UP_PINS) ne ""} {
    set floating_pins [get_pins $env(FLOATING_UP_PINS)]
    set_attribute_value $floating_pins -name ignore_during_icl_extraction
}

check_design_rules
write_design -tsdb -verbose
extract_icl

puts "Stack ICL extraction completed in $env(STACK_TSDB)"
exit
