# Stack-level IJTAG/ICL verification template.
#
# Required environment variables:
#   STACK_TSDB, STACK_TOP, BASIC_DESIGN, SENSOR_DESIGN, SIM_LIBRARY_TCL
#
# The exact TSDB view and pattern setup calls are release/configuration
# dependent.  Treat a successful process_patterns_specification plus simulation
# as the acceptance criterion; ICL extraction alone is not sufficient.

foreach required_env {
    STACK_TSDB STACK_TOP BASIC_DESIGN SENSOR_DESIGN SIM_LIBRARY_TCL
} {
    if {![info exists env($required_env)] || $env($required_env) eq ""} {
        error "Required environment variable $required_env is not set"
    }
}
if {![file exists $env(SIM_LIBRARY_TCL)]} {
    error "Missing simulation-library setup Tcl: $env(SIM_LIBRARY_TCL)"
}

set_context patterns
set_tsdb_output_directory [file normalize $env(STACK_TSDB)]
read_design $env(SENSOR_DESIGN) \
    -design_id gate -view ijtag_graybox -include_child_blocks_icl_and_pdl
read_design $env(BASIC_DESIGN) \
    -design_id gate -view ijtag_graybox -include_child_blocks_icl_and_pdl
read_design $env(STACK_TOP) \
    -design_id stack_icl_integration -view ijtag_graybox
set_current_design $env(STACK_TOP)
set_system_mode setup

check_design_rules

set_defaults_value \
    /PatternsSpecification/SignoffOptions/simulate_instruments_in_lower_physical_instances \
    on
set pattern_spec [create_patterns_specification -replace]
report_config_data $pattern_spec
process_patterns_specification

# This protected local file calls set_simulation_library_sources with the
# site's standard-cell and memory Verilog simulation models.  A Synopsys .db
# is not a Verilog simulation model and must not be passed here.
source $env(SIM_LIBRARY_TCL)
run_testbench_simulations
check_testbench_simulations -report_status

puts "Stack IJTAG pattern generation and simulation completed"
exit
