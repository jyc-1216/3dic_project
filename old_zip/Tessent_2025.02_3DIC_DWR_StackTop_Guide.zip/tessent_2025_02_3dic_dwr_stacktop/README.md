# Tessent 2025.02：IEEE 1687／1838、DWR 與 `stack_top` 整合包

這份範本依照目前三顆 die 的設定重建：

| Role | Module | Instance | Serial access |
| --- | --- | --- | --- |
| Base | `base_die_top` | `u_base_die` | local IJTAG + `STAP(s1)` |
| Middle | `middle_sram_readout_die_top` | `u_middle_sram_readout_die` | local IJTAG + `STAP(s2)` |
| Top | `top_sram_readout_die_top` | `u_top_sram_readout_die` | local IJTAG，無向上 STAP |

## 最重要的 2025.02 前提

在含有 STAP 的 die 上，`HostIjtag` 與 `HostStap` 必須放在同一個
`DftSpecification`、同一個 `Tap(main)` 下，並由同一次
`process_dft_specification` 處理。不要再使用「先插 IJTAG、之後另開一份
specification 插 STAP」所產生的舊 TSDB。

`die_level_combined_host_2025_02.template.tcl` 只示範這個結構。它故意不猜測
公司設計內部的 `HostIjtag`／`HostStap` 欄位，必須把已在 2025.02 驗證成功的
內容貼回去後才能使用。

## DWR 與 `stack_top` 的分工

- PTAP/STAP/3DCR：負責 IEEE 1838 serial control mechanism。
- IJTAG/SIB/TDR：負責 IEEE 1687 instrument access。
- DWR：包住真正的功能性 die-to-die 資料埠，提供 isolation、capture、
  shift 與 update，供 die-to-die interconnect test 使用。
- `stack_top_extract_icl.tcl`：只組裝已插入完成的 die，建立實體連線、
  輸出 `stack_top.v`，再抽取 package/stack-level ICL；它不在 stack top
  重新插入 DWR。

因此，若要做 DWR/interconnect test，輸入本流程的 final per-die TSDB 必須已
包含正確的 wrapper/scan view。不要在 `read_config_data` 中自行猜一個
`DWR {}` 區塊。

## 內含檔案

- `Tessent_2025.02_3DIC_DWR_StackTop_Guide_zh_TW.docx`：完整操作與除錯文件。
- `die_level_combined_host_2025_02.template.tcl`：同一 specification 內組合
  `HostIjtag + HostStap` 的結構範本。
- `stack_top_config.tcl`：TSDB、module、instance 與實體 port mapping。
- `stack_top_extract_icl.tcl`：discovery 與 final integration 主流程。
- `check_tessent_2025_02_commands.tcl`：在公司 Tessent Shell 中檢查關鍵命令。
- `dwr_port_inventory.csv`：整理功能性 die-to-die ports 與 DWR 規劃。

## 建議執行順序

### 1. 先檢查 2025.02 命令

```csh
tessent -shell -dofile check_tessent_2025_02_commands.tcl
```

若任何命令顯示 `MISSING`，先使用公司安裝版的 `help <command>`、
Tessent Multi-die User's Manual 或 3D Multi-Die support kit 修正 option；
不要直接改變連線拓撲。

### 2. 填入 final per-die TSDB

編輯 `stack_top_config.tcl` 中三個 role 的：

- `tsdb`
- `design_id`
- `module`
- `instance`

三顆 die 的 top module 必須唯一。

### 3. Discovery mode

```csh
setenv STACK_DISCOVERY_ONLY 1
tessent -shell -dofile stack_top_extract_icl.tcl
```

這一步只建立 instance 並列出每顆 die 的 top-level pin 與 direction，不建立
連線，也不輸出半成品。把實際 PTAP/STAP leaf name 填回：

- `stack_package_ports`
- `stack_interdie_connections`

不要假設 `s1_tck`、`s1_tdi` 等 placeholder 就是 2025.02 產生的真實名稱。

### 4. Final integration

```csh
setenv STACK_DISCOVERY_ONLY 0
tessent -shell -dofile stack_top_extract_icl.tcl
```

預期輸出：

- `generated/stack_top.v`
- `import.tcl`
- `tsdb_stack_top/`

## 正確資料方向

| Connection | Source → destination |
| --- | --- |
| Package input | `tck/tms/trst/tdi` → Base PTAP |
| Package output | Base PTAP `tdo` → package `tdo` |
| Base to Middle | Base `STAP(s1)` control/TDI → Middle PTAP |
| Middle return | Middle PTAP `tdo` → Base `STAP(s1)` return |
| Middle to Top | Middle `STAP(s2)` control/TDI → Top PTAP |
| Top return | Top PTAP `tdo` → Middle `STAP(s2)` return |

`CE/SE/UE` 通常是各 die 內部由 TAP/scan network 解碼出的控制訊號，不應因為
波形中看得到就跨 die 連接。`tdo_en` 只有在 discovery 證明兩端皆為真實
die-boundary port，且方向可形成合法 source-to-destination 時才加入。

## 重要限制

這個環境沒有 Siemens Tessent 2025.02 執行檔與授權，因此壓縮檔已做文字結構、
placeholder、連線方向與 DOCX 版面檢查，但無法代替公司環境中的
Tessent command-option 驗證。最終仍要以安裝版 `help` 與 support kit 為準。

