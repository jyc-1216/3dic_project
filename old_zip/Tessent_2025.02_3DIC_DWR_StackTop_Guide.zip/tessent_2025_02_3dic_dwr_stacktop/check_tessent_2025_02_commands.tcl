# =============================================================================
# Read-only command availability check for the Tessent 2025.02 stack-top flow.
#
# Run:
#   tessent -shell -dofile check_tessent_2025_02_commands.tcl
#
# This does not prove that every option is identical across installations.
# For each PRESENT command, run "help <command>" interactively and compare the
# exact option form with stack_top_extract_icl.tcl.
# =============================================================================

set commands_to_check {
    set_context
    set_tsdb_output_directory
    open_tsdb
    read_design
    create_module
    create_instance
    create_port
    create_connection
    get_instances
    get_pins
    get_ports
    sizeof_collection
    get_single_attribute_value
    set_attribute_value
    write_design
    extract_icl
    write_design_import_script
    analyze_drc_violation
}

puts "TESSENT 2025.02 COMMAND AVAILABILITY"
puts "===================================="

set missing_commands {}
foreach command_name $commands_to_check {
    if {[llength [info commands $command_name]] == 0} {
        puts [format "%-36s MISSING" $command_name]
        lappend missing_commands $command_name
    } else {
        puts [format "%-36s PRESENT" $command_name]
    }
}

puts ""
if {[llength $missing_commands] == 0} {
    puts "RESULT: all referenced command names are present."
    puts "NEXT  : verify each option form with help <command>."
} else {
    puts "RESULT: missing commands: $missing_commands"
    puts "NEXT  : confirm Multi-die product/license, context, and 2025.02 syntax."
}

exit

