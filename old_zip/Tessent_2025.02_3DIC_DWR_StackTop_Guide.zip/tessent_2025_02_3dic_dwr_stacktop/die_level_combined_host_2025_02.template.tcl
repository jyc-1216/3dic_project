# =============================================================================
# Tessent 2025.02 structural template:
# put HostIjtag and HostStap under the SAME Tap(main) and read_config_data call.
#
# This is intentionally a TEMPLATE, not a drop-in company script.
# Preserve the exact HostIjtag/HostStap bodies that already pass in the local
# Tessent 2025.02 installation.
# =============================================================================

set spec [create_dft_specification]

set main_tap_path \
    $spec/IjtagNetwork/HostScanInterface(tap)/Tap(main)

# -----------------------------------------------------------------------------
# Base die example: local IJTAG + one downstream STAP(s1)
# -----------------------------------------------------------------------------
#
# read_config_data \
#     -in $main_tap_path \
#     -from_string {
#         HostIjtag(1) {
#             # Paste the complete, already validated 2025.02 HostIjtag body.
#             # Keep the local SIB/TDR/instrument configuration here.
#         }
#
#         HostStap(s1) {
#             # Paste the complete, already validated 2025.02 HostStap body.
#             # Do not invent field names from an older release.
#         }
#     }

# -----------------------------------------------------------------------------
# Middle die example: local IJTAG + one downstream STAP(s2)
# -----------------------------------------------------------------------------
#
# read_config_data \
#     -in $main_tap_path \
#     -from_string {
#         HostIjtag(1) {
#             # Paste the complete middle-die HostIjtag body.
#         }
#
#         HostStap(s2) {
#             # Paste the complete middle-die HostStap body.
#         }
#     }

# -----------------------------------------------------------------------------
# Top die example: local IJTAG only; no unused upward HostStap
# -----------------------------------------------------------------------------
#
# read_config_data \
#     -in $main_tap_path \
#     -from_string {
#         HostIjtag(1) {
#             # Paste the complete top-die HostIjtag body.
#         }
#     }

# Only one of the role-specific read_config_data blocks above belongs in each
# die script.  After filling and enabling the selected block, keep the usual:
#
# report_config_data $spec
# process_dft_specification -validate_only
# process_dft_specification
# extract_icl
# write_design -tsdb -verbose
#
# Acceptance gate:
#   * one HostScanInterface(tap)/Tap(main) root;
#   * existing local IJTAG remains reachable;
#   * Base has exactly STAP(s1);
#   * Middle has exactly STAP(s2);
#   * Top has no unused upward STAP;
#   * no second parallel TAP access root.

