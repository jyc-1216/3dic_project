# =============================================================================
# Tessent 2025.02 three-die IEEE 1687 / IEEE 1838 stack configuration
#
# This file describes assembly data only.  It does not insert PTAP, STAP,
# IJTAG, or DWR hardware.
#
# Required per-die prerequisite:
#   * Base and Middle: HostIjtag + HostStap were defined under the same
#     Tap(main), in one read_config_data call, and processed in one
#     process_dft_specification execution.
#   * Top: HostIjtag under the PTAP; no unused upward HostStap.
#   * If DWR/interconnect test is required, use a final per-die TSDB that
#     already contains the intended wrapper/scan view.
# =============================================================================

set target_tessent_release 2025.02

set stack_top_name       stack_top
set stack_design_id      stack_rtl
set stack_generated_dir  [file normalize ${script_dir}/generated]
set stack_tsdb_dir       [file normalize ${script_dir}/tsdb_stack_top]
set stack_top_verilog    ${stack_generated_dir}/stack_top.v
set stack_import_tcl     ${script_dir}/import.tcl

# First run:
#   setenv STACK_DISCOVERY_ONLY 1
#   tessent -shell -dofile stack_top_extract_icl.tcl
#
# Final run:
#   setenv STACK_DISCOVERY_ONLY 0
#   tessent -shell -dofile stack_top_extract_icl.tcl
set stack_discovery_only 0
if {[info exists env(STACK_DISCOVERY_ONLY)]} {
    set stack_discovery_only $env(STACK_DISCOVERY_ONLY)
}

# Replace these paths and design IDs with the FINAL matching per-die TSDB
# views.  Keep all three module names unique.
set die_config [dict create \
    base [dict create \
        tsdb      [file normalize ${script_dir}/../base_die/tsdb_base_1838_final] \
        design_id rtl_1687_1838_final \
        module    base_die_top \
        instance  u_base_die] \
    middle [dict create \
        tsdb      [file normalize ${script_dir}/../middle_sram_readout_die/tsdb_middle_1838_final] \
        design_id rtl_1687_1838_final \
        module    middle_sram_readout_die_top \
        instance  u_middle_sram_readout_die] \
    top [dict create \
        tsdb      [file normalize ${script_dir}/../top_sram_readout_die/tsdb_top_1838_final] \
        design_id rtl_1687_1838_final \
        module    top_sram_readout_die_top \
        instance  u_top_sram_readout_die] \
]

# Package boundary <-> Base PTAP
#
# Row:
#   {stack_port stack_direction die_role die_pin}
#
# stack_direction is the direction of the stack_top port:
#   input  : stack port is the source and drives a Base die input
#   output : Base die output is the source and drives the stack port
#
# Replace only the die_pin field after discovery if the inserted RTL uses
# names such as ptap_tck or another generated prefix.
set stack_package_ports {
    {tck  input  base tck}
    {tms  input  base tms}
    {trst input  base trst}
    {tdi  input  base tdi}
    {tdo  output base tdo}
}

# Functions assigned to stack-level PTAP ports before extract_icl.
set stack_tap_functions {
    {tck  tck}
    {tms  tms}
    {trst trst}
    {tdi  tdi}
    {tdo  tdo}
}

# Inter-die serial access wiring.
#
# Row:
#   {source_die_role source_pin destination_die_role destination_pin}
#
# Forward direction: STAP control/TDI -> downstream PTAP.
# Return direction : downstream PTAP TDO -> upstream STAP return.
#
# Leaf names below are placeholders.  Discovery mode is mandatory.
set stack_interdie_connections {
    {base   s1_tck  middle tck}
    {base   s1_tms  middle tms}
    {base   s1_trst middle trst}
    {base   s1_tdi  middle tdi}
    {middle tdo     base   s1_tdo}

    {middle s2_tck  top    tck}
    {middle s2_tms  top    tms}
    {middle s2_trst top    trst}
    {middle s2_tdi  top    tdi}
    {top    tdo     middle s2_tdo}
}

# Optional physical functional die-to-die connections.
#
# Add only real boundary pins that discovery reports, and keep each row in
# source -> destination order.  These nets are distinct from CE/SE/UE.
#
# Example:
#   lappend stack_optional_connections \
#       {base sensor_cfg_out middle sensor_cfg_in}
#
# DWR note:
#   Adding a physical connection here does not insert DWR cells.  The final
#   per-die TSDB must already carry the matching DWR/wrapper view.
set stack_optional_connections {
}

# Add tdo_en only if discovery proves that it is a real boundary output on one
# side and a matching boundary input on the other side.
#
# Do not connect internal CE, SE, or UE controls between dies.

