# =============================================================================
# Tessent 2025.02 three-die stack_top construction and combined ICL extraction
#
# Flow:
#   final per-die TSDBs
#     -> read_design
#     -> create_module/create_instance
#     -> discovery report
#     -> create_port/create_connection
#     -> write_design generated/stack_top.v
#     -> extract_icl
#     -> write_design_import_script import.tcl
#
# Discovery:
#   setenv STACK_DISCOVERY_ONLY 1
#   tessent -shell -dofile stack_top_extract_icl.tcl
#
# Final:
#   setenv STACK_DISCOVERY_ONLY 0
#   tessent -shell -dofile stack_top_extract_icl.tcl
# =============================================================================

set script_dir [file dirname [file normalize [info script]]]
source ${script_dir}/stack_top_config.tcl

file mkdir $stack_generated_dir
file mkdir $stack_tsdb_dir

proc require_directory {label path} {
    if {![file isdirectory $path]} {
        error "$label directory does not exist: $path"
    }
}

proc get_die_field {role field} {
    global die_config
    if {![dict exists $die_config $role $field]} {
        error "Missing die_config field '$field' for role '$role'"
    }
    return [dict get $die_config $role $field]
}

proc get_exact_instance {instance_name} {
    set objects [get_instances [list $instance_name]]
    set count [sizeof_collection $objects]
    if {$count != 1} {
        error "Expected one instance '$instance_name', found $count"
    }
    return $objects
}

proc get_exact_scalar_pin {role pin_leaf_name} {
    set instance_name [get_die_field $role instance]
    set instance_obj  [get_exact_instance $instance_name]
    set pins [get_pins [list $pin_leaf_name] -of_instances $instance_obj]
    set count [sizeof_collection $pins]
    if {$count != 1} {
        error "Expected one scalar pin '$instance_name/$pin_leaf_name', found $count. Run with STACK_DISCOVERY_ONLY=1 and copy the exact generated leaf name into stack_top_config.tcl."
    }
    return $pins
}

proc pin_direction {pin_obj} {
    return [get_single_attribute_value -name direction $pin_obj]
}

proc require_source_direction {label direction} {
    if {$direction eq "input"} {
        error "Configured source '$label' is an input"
    }
}

proc require_destination_direction {label direction} {
    if {$direction eq "output"} {
        error "Configured destination '$label' is an output"
    }
}

proc connect_die_pins {source_role source_pin destination_role destination_pin} {
    set source_obj      [get_exact_scalar_pin $source_role $source_pin]
    set destination_obj [get_exact_scalar_pin $destination_role $destination_pin]

    set source_label "[get_die_field $source_role instance]/$source_pin"
    set destination_label "[get_die_field $destination_role instance]/$destination_pin"

    require_source_direction \
        $source_label \
        [pin_direction $source_obj]
    require_destination_direction \
        $destination_label \
        [pin_direction $destination_obj]

    puts "CONNECT: $source_label -> $destination_label"
    create_connection $source_obj $destination_obj
}

proc expose_package_port {top_port direction role die_pin} {
    set die_pin_obj [get_exact_scalar_pin $role $die_pin]
    set die_direction [pin_direction $die_pin_obj]
    set die_label "[get_die_field $role instance]/$die_pin"

    if {$direction ne "input" && $direction ne "output"} {
        error "Package port '$top_port' must be input or output, got '$direction'"
    }
    if {$direction ne $die_direction} {
        error "Direction mismatch for package port '$top_port': stack=$direction, $die_label=$die_direction"
    }

    set port_obj [create_port $top_port -direction $direction]

    if {$direction eq "input"} {
        puts "PACKAGE INPUT : $top_port -> $die_label"
        create_connection $port_obj $die_pin_obj
    } else {
        puts "PACKAGE OUTPUT: $die_label -> $top_port"
        create_connection $die_pin_obj $port_obj
    }
}

proc report_die_pins {role} {
    set instance_name [get_die_field $role instance]
    set instance_obj  [get_exact_instance $instance_name]

    puts ""
    puts "============================================================"
    puts "TOP PINS: role=$role instance=$instance_name"
    puts "============================================================"

    set pin_rows {}
    foreach_in_collection pin [get_pins * -of_instances $instance_obj] {
        set leaf_name [get_single_attribute_value -name leaf_name $pin]
        set direction [get_single_attribute_value -name direction $pin]
        lappend pin_rows [list $leaf_name $direction]
    }

    foreach row [lsort -dictionary -index 0 $pin_rows] {
        puts [format "%-64s %s" [lindex $row 0] [lindex $row 1]]
    }
}

# -----------------------------------------------------------------------------
# 1. Load the final matching HDL + ICL/PDL/TCD view of every die.
# -----------------------------------------------------------------------------

puts "TARGET TESSENT RELEASE: $target_tessent_release"
set_context dft -rtl -design_id $stack_design_id
set_tsdb_output_directory $stack_tsdb_dir

foreach role {base middle top} {
    set tsdb_path   [get_die_field $role tsdb]
    set design_id   [get_die_field $role design_id]
    set module_name [get_die_field $role module]

    require_directory "TSDB for $role die" $tsdb_path

    puts "OPEN TSDB: role=$role path=$tsdb_path"
    open_tsdb $tsdb_path

    puts "READ DIE: role=$role module=$module_name design_id=$design_id"
    read_design $module_name -design_id $design_id -view full
}

set configured_modules {}
foreach role {base middle top} {
    lappend configured_modules [get_die_field $role module]
}
if {[llength [lsort -unique $configured_modules]] != 3} {
    error "Base, Middle, and Top die module names must be unique: $configured_modules"
}

# -----------------------------------------------------------------------------
# 2. Create stack_top and instantiate the three already-inserted die views.
# -----------------------------------------------------------------------------

set_system_mode insertion
set_current_design [create_module $stack_top_name]
set_design_level chip

foreach role {base middle top} {
    set instance_name [get_die_field $role instance]
    set module_name   [get_die_field $role module]
    puts "CREATE INSTANCE: $instance_name of $module_name"
    create_instance $instance_name -of_module $module_name
}

foreach role {base middle top} {
    report_die_pins $role
}

if {$stack_discovery_only} {
    puts ""
    puts "DISCOVERY ONLY: no connections or outputs were written."
    puts "Copy the exact PTAP/STAP leaf names above into stack_top_config.tcl."
    puts "Then rerun with STACK_DISCOVERY_ONLY=0."
    exit
}

# -----------------------------------------------------------------------------
# 3. Create package ports and legal, directed inter-die connections.
# -----------------------------------------------------------------------------

foreach row $stack_package_ports {
    if {[llength $row] != 4} {
        error "Bad stack_package_ports row: $row"
    }
    lassign $row top_port direction role die_pin
    expose_package_port $top_port $direction $role $die_pin
}

foreach row [concat $stack_interdie_connections $stack_optional_connections] {
    if {[llength $row] != 4} {
        error "Bad stack connection row: $row"
    }
    lassign $row source_role source_pin destination_role destination_pin
    connect_die_pins $source_role $source_pin $destination_role $destination_pin
}

# -----------------------------------------------------------------------------
# 4. Let Tessent write the structural Verilog-2001 stack and save a TSDB view.
# -----------------------------------------------------------------------------

puts "WRITE STRUCTURAL VERILOG: $stack_top_verilog"
write_design -output_file $stack_top_verilog -replace

puts "SAVE PRE-EXTRACTION STACK VIEW: $stack_tsdb_dir"
write_design -tsdb -verbose

# -----------------------------------------------------------------------------
# 5. Extract one stack-level ICL model.
#
# Do not create/process a new DftSpecification here.  HostIjtag, HostStap,
# PTAP/STAP/3DCR, and any DWR hardware already belong to each die-level view.
# stack_top only describes assembly connectivity and extracts the combined
# access model.
# -----------------------------------------------------------------------------

set_system_mode setup
set_current_design $stack_top_name
set_design_level chip

foreach row $stack_tap_functions {
    if {[llength $row] != 2} {
        error "Bad stack_tap_functions row: $row"
    }
    lassign $row port_name function_name
    set port_obj [get_ports [list $port_name]]
    if {[sizeof_collection $port_obj] != 1} {
        error "Expected one stack port '$port_name'"
    }
    set_attribute_value $port_obj -name function -value $function_name
}

puts "EXTRACT COMBINED ICL: design=$stack_top_name"
if {[catch {extract_icl} extract_message extract_options]} {
    puts ""
    puts "ICL extraction failed. Inspect the first I-rule violation."
    puts "Useful interactive command:"
    puts "  analyze_drc_violation <I-rule-ID>"
    error $extract_message
}

puts "SAVE FINAL STACK VIEW: $stack_tsdb_dir"
write_design -tsdb -verbose

# -----------------------------------------------------------------------------
# 6. Generate import.tcl from the final stack design.
# -----------------------------------------------------------------------------

puts "WRITE IMPORT TCL: $stack_import_tcl"
write_design_import_script \
    $stack_import_tcl \
    -replace \
    -use_relative_path_to $script_dir

puts ""
puts "STACK-TOP ICL INTEGRATION COMPLETED"
puts "Top module       : $stack_top_name"
puts "Structural RTL   : $stack_top_verilog"
puts "Import Tcl       : $stack_import_tcl"
puts "Stack TSDB       : $stack_tsdb_dir"
puts "Combined ICL     : stored in the final stack TSDB view"
exit
