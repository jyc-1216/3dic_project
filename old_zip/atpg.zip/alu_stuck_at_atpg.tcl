# Automatic stuck-at ATPG for the combinational lower-die ALU.
#
# Required:
#   TESSENT_CELL_LIBRARY
#
# Optional:
#   PROJECT_DIR      Default: directory containing this Tcl file
#   ATPG_OUTPUT_ROOT Default: atpg_out
#   ALU_TOP          Default: lower_die_alu_core
#   ALU_NETLIST      Default: netlist/lower_die_alu_core_syn.v
#
# This flow generates core-level ALU patterns. It does not run stack-level
# retargeting and does not perform DWR interconnect ATPG.

proc env_or_default {name default_value} {
    if {[info exists ::env($name)] && $::env($name) ne ""} {
        return $::env($name)
    }
    return $default_value
}

proc env_required {name} {
    if {![info exists ::env($name)] || $::env($name) eq ""} {
        error "Required environment variable $name is not set"
    }
    return $::env($name)
}

proc resolve_path {project_dir path_value} {
    if {[file pathtype $path_value] eq "absolute"} {
        return [file normalize $path_value]
    }
    return [file normalize [file join $project_dir $path_value]]
}

proc require_file {path_value description} {
    if {![file isfile $path_value]} {
        error "$description does not exist: $path_value"
    }
}

proc add_all_faults_compat {} {
    if {[llength [info commands add_faults]] > 0} {
        add_faults -all
    } elseif {[llength [info commands add_fault]] > 0} {
        add_fault -all
    } else {
        error "Neither add_faults nor add_fault is available in this Tessent release"
    }
}

set script_dir  [file dirname [file normalize [info script]]]
set project_dir [file normalize [env_or_default PROJECT_DIR $script_dir]]

set tcelllib [resolve_path $project_dir [env_required TESSENT_CELL_LIBRARY]]
set top      [env_or_default ALU_TOP lower_die_alu_core]
set netlist  [resolve_path $project_dir \
    [env_or_default ALU_NETLIST netlist/lower_die_alu_core_syn.v]]
set output_root [resolve_path $project_dir \
    [env_or_default ATPG_OUTPUT_ROOT atpg_out]]
set output_dir [file join $output_root alu]

require_file $tcelllib "Tessent cell library"
require_file $netlist "ALU gate-level netlist"
file mkdir $output_dir

puts "============================================================"
puts "Flow        : ALU automatic stuck-at ATPG"
puts "Top design  : $top"
puts "Netlist     : $netlist"
puts "Output      : $output_dir"
puts "============================================================"

set_context patterns -scan
set_tsdb_output_directory [file join $output_dir tsdb]

read_cell_library $tcelllib
read_verilog $netlist
set_current_design $top
set_current_mode alu_stuck -type internal

check_design_rules
set_system_mode analysis
set_fault_type stuck
add_all_faults_compat

create_patterns
report_statistics -detail

write_tsdb_data -replace
write_patterns [file join $output_dir lower_die_alu_stuck.stil.gz] \
    -stil -replace
write_patterns [file join $output_dir lower_die_alu_stuck_parallel.v] \
    -verilog -parallel -replace \
    -parameter_list {SIM_KEEP_PATH 1}

puts "ALU stuck-at ATPG completed"
puts "A scan-cell count of zero is expected for this combinational core"

exit
