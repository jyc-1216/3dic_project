# Stuck-at fault grading for an existing sensor functional pattern set.
#
# Required:
#   TESSENT_CELL_LIBRARY
#
# Optional:
#   PROJECT_DIR      Default: directory containing this Tcl file
#   ATPG_OUTPUT_ROOT Default: atpg_out
#   SENSOR_TOP       Default: upper_die_top
#   SENSOR_NETLIST   Default: netlist/upper_die_top_syn.v
#   SENSOR_PATTERN   Default: patterns/upper_sensor_functional.stil
#   SENSOR_CLOCKS    Default: {clk tck}
#   SENSOR_INSTANCE  Default: u_temperature; set empty to skip instance report
#
# This flow grades existing STIL/PatDB patterns. It does not call
# create_patterns and therefore is not full sequential ATPG.

proc env_or_default {name default_value} {
    if {[info exists ::env($name)] && $::env($name) ne ""} {
        return $::env($name)
    }
    return $default_value
}

proc env_required {name} {
    if {![info exists ::env($name)] || $::env($name) eq ""} {
        error "Required environment variable $name is not set"
    }
    return $::env($name)
}

proc resolve_path {project_dir path_value} {
    if {[file pathtype $path_value] eq "absolute"} {
        return [file normalize $path_value]
    }
    return [file normalize [file join $project_dir $path_value]]
}

proc require_file {path_value description} {
    if {![file isfile $path_value]} {
        error "$description does not exist: $path_value"
    }
}

proc add_all_faults_compat {} {
    if {[llength [info commands add_faults]] > 0} {
        add_faults -all
    } elseif {[llength [info commands add_fault]] > 0} {
        add_fault -all
    } else {
        error "Neither add_faults nor add_fault is available in this Tessent release"
    }
}

set script_dir  [file dirname [file normalize [info script]]]
set project_dir [file normalize [env_or_default PROJECT_DIR $script_dir]]

set tcelllib [resolve_path $project_dir [env_required TESSENT_CELL_LIBRARY]]
set top      [env_or_default SENSOR_TOP upper_die_top]
set netlist  [resolve_path $project_dir \
    [env_or_default SENSOR_NETLIST netlist/upper_die_top_syn.v]]
set pattern  [resolve_path $project_dir \
    [env_or_default SENSOR_PATTERN patterns/upper_sensor_functional.stil]]
set sensor_clocks [env_or_default SENSOR_CLOCKS {clk tck}]
if {[info exists ::env(SENSOR_INSTANCE)]} {
    set sensor_instance $::env(SENSOR_INSTANCE)
} else {
    set sensor_instance u_temperature
}
set output_root [resolve_path $project_dir \
    [env_or_default ATPG_OUTPUT_ROOT atpg_out]]
set output_dir [file join $output_root sensor_grade]

require_file $tcelllib "Tessent cell library"
require_file $netlist "Sensor-die gate-level netlist"
require_file $pattern "Sensor functional pattern"
file mkdir $output_dir

puts "============================================================"
puts "Flow        : Sensor functional-pattern stuck-at fault grading"
puts "Top design  : $top"
puts "Netlist     : $netlist"
puts "Pattern     : $pattern"
puts "Output      : $output_dir"
puts "============================================================"

set_context patterns -scan
set_tsdb_output_directory [file join $output_dir tsdb]

read_cell_library $tcelllib
read_verilog $netlist
set_current_design $top
set_current_mode sensor_functional_grade -type internal

foreach clock_name $sensor_clocks {
    add_clocks 0 $clock_name
}

check_design_rules
set_system_mode analysis
set_fault_type stuck
add_all_faults_compat

read_patterns $pattern
simulate_patterns -source external
report_statistics -detail

if {$sensor_instance ne ""} {
    if {[catch {
        report_statistics -instance $sensor_instance
    } instance_error]} {
        puts "WARNING: Per-instance report was not generated: $instance_error"
        puts "If synthesis flattened the hierarchy, leave SENSOR_INSTANCE empty"
    }
}

write_tsdb_data -replace
write_patterns [file join $output_dir upper_sensor_functional_graded.stil.gz] \
    -stil -replace

puts "Sensor functional-pattern stuck-at fault grading completed"
puts "This result is fault grading, not full sequential ATPG"

exit
