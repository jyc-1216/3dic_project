Tessent RTL Pass 2 bundle

Recommended order
1. backup_C_schema_probe_no_insert.tcl
2. pass2_upgrade_1687_to_1838_rtl.tcl with SPEC_ONLY=1
3. pass2_upgrade_1687_to_1838_rtl.tcl with SPEC_ONLY=0
4. backup_A_explicit_inserted_rtl_and_icl.tcl if TSDB reload does not restore ICL matching
5. backup_B_rebuild_one_pass_1687_1838.tcl only if both cumulative flows fail

Main assumptions
- Pass 1 is RTL-level IEEE 1687 insertion.
- Pass 1 completed extract_icl and write_design -tsdb.
- Pass 1 PDL retargeting and RTL waveform simulation already pass.
- Pass 2 must not read golden RTL.
- Pass 2 must not re-add HostIjtag, SIB, or TDR.
- DWR insertion is intentionally outside this bundle.

Die roles
- bottom: existing TAP becomes PTAP; add one STAP per directly connected upper die.
- middle: existing TAP becomes PTAP; add one STAP per directly connected upper die.
- top: existing TAP becomes PTAP; add no STAP. Confirm Tessent 2025.02 PTAP-only syntax locally before insertion.

First-run safety settings
- SPEC_ONLY=1
- ALLOW_ATTRIBUTE_REPAIR=0

Minimum acceptance checks
- one TAP/PTAP access root
- original local IJTAG PDL still retargets
- bottom/middle STAP reaches the next die PTAP
- no duplicated HostIjtag/SIB/TDR
- extracted ICL matches inserted RTL
