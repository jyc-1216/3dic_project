# =============================================================================
# Backup A: explicit Pass 1 inserted RTL + extracted ICL import
#
# Use only when read_design from the Pass 1 TSDB does not restore or match the
# existing TAP/IJTAG model.  The ICL must be read before set_current_design.
#
# Required:
#   DIE_POSITION=bottom|middle|top
#   TOP_MODULE=basic_die_top
#   PASS1_INSERTED_RTL=/absolute/path/pass1_inserted.v
#   PASS1_EXTRACTED_ICL=/absolute/path/pass1_extracted.icl
#   STAP_HOST_LIST="s1"                  # bottom/middle
#   TOP_PTAP_STRATEGY=empty_stap_list    # top, only after local help confirms
# =============================================================================

proc required_env {name} {
    global env
    if {![info exists env($name)] || $env($name) eq ""} {
        error "Set required environment variable $name"
    }
    return $env($name)
}

proc env_or {name default_value} {
    global env
    if {[info exists env($name)] && $env($name) ne ""} {
        return $env($name)
    }
    return $default_value
}

proc split_host_list {raw} {
    set normalized [string map [list "," " " ";" " "] $raw]
    set result [list]
    foreach item [split $normalized] {
        if {$item ne ""} {
            lappend result $item
        }
    }
    return $result
}

set die_position [string tolower [required_env DIE_POSITION]]
if {$die_position ni [list bottom middle top]} {
    error "DIE_POSITION must be bottom, middle, or top"
}

set top_module      [env_or TOP_MODULE basic_die_top]
set inserted_rtl    [file normalize [required_env PASS1_INSERTED_RTL]]
set extracted_icl   [file normalize [required_env PASS1_EXTRACTED_ICL]]
set tsdb_dir        [file normalize [env_or TSDB_DIR ./tsdb_explicit_pass2]]
set pass2_design_id [env_or PASS2_DESIGN_ID rtl_1687_1838_explicit_${die_position}]
set output_dir      [file normalize [env_or OUTPUT_DIR ./generated_explicit_pass2]]

foreach required_file [list $inserted_rtl $extracted_icl] {
    if {![file exists $required_file]} {
        error "Missing input file: $required_file"
    }
}

file mkdir $tsdb_dir
file mkdir $output_dir

set_context dft -rtl -design_id $pass2_design_id
set_tsdb_output_directory $tsdb_dir

read_verilog $inserted_rtl

# Ordering requirement: read ICL before current-design elaboration.
read_icl $extracted_icl

set_current_design $top_module
set_design_level chip

if {[catch {report_module_matching -icl} matching_error]} {
    puts "WARNING: report_module_matching -icl failed: $matching_error"
}

set_dft_specification_requirements -host_scan_interface_type tap
check_design_rules

switch -- $die_position {
    bottom -
    middle {
        set stap_hosts [split_host_list [env_or STAP_HOST_LIST s1]]
        if {[llength $stap_hosts] == 0} {
            error "$die_position die requires at least one downstream STAP host"
        }
        set spec [create_dft_specification \
            -stap_host_list $stap_hosts]
    }
    top {
        if {[string tolower [env_or TOP_PTAP_STRATEGY ""]] ne "empty_stap_list"} {
            help create_dft_specification
            error "Confirm the Tessent 2025.02 PTAP-only syntax, then set TOP_PTAP_STRATEGY=empty_stap_list only if the empty-list form is supported"
        }
        set spec [create_dft_specification \
            -stap_host_list [list]]
    }
}

report_config_data $spec
process_dft_specification -validate_only

if {[string tolower [env_or SPEC_ONLY 1]] in [list 1 true yes on]} {
    puts "SPEC_ONLY defaulted to 1. Inspect the specification before insertion."
    exit
}

process_dft_specification
extract_icl
write_design -tsdb -verbose

write_design \
    -output_file ${output_dir}/${top_module}_${die_position}_explicit_1687_1838.v \
    -replace

write_design_import_script \
    ${output_dir}/${top_module}_${die_position}_explicit_dc_import.tcl \
    -replace \
    -use_relative_path_to [pwd]

exit
