# =============================================================================
# Backup B: rebuild IEEE 1687 + IEEE 1838 in one RTL insertion specification
#
# Use only if cumulative Pass 2 and explicit RTL+ICL import both fail.
# This flow starts from golden RTL, so paste the exact already-verified Pass 1
# Sib/Tdr configuration into the marked block.  Do not create a second
# HostScanInterface/Tap.
#
# This template is intentionally SPEC_ONLY by default.
# =============================================================================

proc required_env {name} {
    global env
    if {![info exists env($name)] || $env($name) eq ""} {
        error "Set required environment variable $name"
    }
    return $env($name)
}

proc env_or {name default_value} {
    global env
    if {[info exists env($name)] && $env($name) ne ""} {
        return $env($name)
    }
    return $default_value
}

set die_position [string tolower [required_env DIE_POSITION]]
if {$die_position ni [list bottom middle]} {
    error "This fallback template is enabled for bottom/middle first. Handle top only after confirming the 2025.02 PTAP-only create option."
}

set top_module       [env_or TOP_MODULE basic_die_top]
set golden_rtl_list  [required_env GOLDEN_RTL_LIST]
set tsdb_dir         [file normalize [env_or TSDB_DIR ./tsdb_rebuild_one_pass]]
set design_id        [env_or DESIGN_ID rtl_1687_1838_rebuild_${die_position}]
set host_config_path [env_or IJTAG_HOST_CONFIG_PATH \
    "IjtagNetwork/HostScanInterface(tap)/Tap(main)/HostIjtag(1)"]

set_context dft -rtl -design_id $design_id
set_tsdb_output_directory $tsdb_dir

foreach rtl_file $golden_rtl_list {
    if {![file exists $rtl_file]} {
        error "Missing golden RTL file: $rtl_file"
    }
    read_verilog $rtl_file
}

set_current_design $top_module
set_design_level chip

foreach {port_name function_name} {
    tck  tck
    tms  tms
    tdi  tdi
    tdo  tdo
    trst trst
} {
    set port_object [get_ports $port_name]
    if {[sizeof_collection $port_object] != 1} {
        error "Expected one top-level port '$port_name'"
    }
    set_attribute_value $port_object \
        -name function \
        -value $function_name
}

set_dft_specification_requirements -host_scan_interface_type tap
check_design_rules

set spec [create_dft_specification \
    -stap_host_list [list s1]]

report_config_data $spec

set ijtag_host ${spec}/${host_config_path}
if {[catch {report_config_data $ijtag_host} path_error]} {
    error "Generated HostIjtag path not found. Copy the exact path from report_config_data into IJTAG_HOST_CONFIG_PATH. No second TAP was created. Tessent message: $path_error"
}

# Replace this example with the exact Sib/Tdr block from the verified Pass 1.
read_config_data -in $ijtag_host -from_string {
    Sib(alu) {
        Tdr(alu_tdr) {
            length : 30;

            DataOutPorts {
                connection(7:0)   : u_alu/operand_a[7:0];
                connection(15:8)  : u_alu/operand_b[7:0];
                connection(18:16) : u_alu/opcode[2:0];
            }

            DataInPorts {
                connection(26:19) : u_alu/result[7:0];
                connection(27)    : u_alu/zero_flag;
                connection(28)    : u_alu/carry_flag;
                connection(29)    : u_alu/overflow_flag;
            }
        }
    }
}

report_config_data $spec
process_dft_specification -validate_only

if {[string tolower [env_or SPEC_ONLY 1]] in [list 1 true yes on]} {
    puts "SPEC_ONLY defaulted to 1. Verify one TAP/PTAP root before insertion."
    exit
}

process_dft_specification
extract_icl
write_design -tsdb -verbose
exit
