# =============================================================================
# Backup C: Tessent 2025.02 schema/host recognition probe
#
# Read the cumulative Pass 1 RTL design view, create and validate the requested
# Multi-die specification, print diagnostic information, and exit before any
# process_dft_specification insertion or write_design operation.
#
# Use this first when create_dft_specification succeeds but the expected
# existing TAP/PTAP host hierarchy is unclear.
# =============================================================================

proc env_or {name default_value} {
    global env
    if {[info exists env($name)] && $env($name) ne ""} {
        return $env($name)
    }
    return $default_value
}

set die_position [string tolower [env_or DIE_POSITION bottom]]
if {$die_position ni [list bottom middle top]} {
    error "DIE_POSITION must be bottom, middle, or top"
}

set top_module      [env_or TOP_MODULE basic_die_top]
set tsdb_dir        [file normalize [env_or TSDB_DIR ./tsdb_basic]]
set pass1_design_id [env_or PASS1_DESIGN_ID rtl_1687]
set probe_design_id [env_or PROBE_DESIGN_ID rtl_1838_schema_probe_${die_position}]

set_context dft -rtl -design_id $probe_design_id
set_tsdb_output_directory $tsdb_dir

read_design $top_module \
    -design_id $pass1_design_id \
    -verbose

set_current_design $top_module
set_design_level chip

puts "===== HELP: create_dft_specification ====="
help create_dft_specification

puts "===== HELP: set_attribute_value ====="
help set_attribute_value

puts "===== PASS 1 ICL MATCHING ====="
if {[catch {report_module_matching -icl} matching_error]} {
    puts "report_module_matching -icl failed: $matching_error"
}

puts "===== TEST-PORT ATTRIBUTES ====="
foreach port_name [list tck tms tdi tdo trst] {
    set port_objects [get_ports $port_name]
    puts "PORT $port_name count=[sizeof_collection $port_objects]"
    if {[sizeof_collection $port_objects] > 0} {
        report_attributes $port_objects
    }
}

set_dft_specification_requirements -host_scan_interface_type tap
check_design_rules

if {$die_position in [list bottom middle]} {
    set spec [create_dft_specification \
        -stap_host_list [list s1]]
} else {
    if {[string tolower [env_or TOP_PTAP_STRATEGY ""]] ne "empty_stap_list"} {
        error "Top-die probe stopped after help output. If documented by local help, rerun with TOP_PTAP_STRATEGY=empty_stap_list."
    }
    set spec [create_dft_specification \
        -stap_host_list [list]]
}

puts "===== GENERATED SPECIFICATION ====="
report_config_data $spec

puts "===== VALIDATION ====="
process_dft_specification -validate_only

puts "SCHEMA_PROBE_COMPLETED: no insertion and no design write were performed"
exit
