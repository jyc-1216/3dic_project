Tessent RTL Pass 2 bundle

Current priority
1. Establish IEEE 1838 correctly.
2. Insert and validate DWR only after step 1 passes.
3. Debug set_attribute only after steps 1 and 2 pass.

The main Tcl now handles IEEE 1838 only.  It contains no DWR insertion and no
set_attribute_value command.

Recommended order for the current bottom Basic/ALU die
1. Run pass2_upgrade_1687_to_1838_rtl.tcl with IEEE1838_PHASE=spec.
2. Inspect report_config_data and accept only one existing-TAP-to-PTAP access root.
3. Rerun with IEEE1838_PHASE=insert and CONFIRM_1838_SPEC=YES.
4. Collect the generated inserted RTL, extracted ICL, import Tcl, and Tessent SDC.
5. Retarget and simulate the already working local IJTAG PDL using the new Pass 2 ICL.
6. Stop here.  Do not begin DWR or set_attribute debugging in the same run.

Fallbacks, only if the main TSDB reload does not recognize Pass 1
1. backup_A_explicit_inserted_rtl_and_icl.tcl
2. backup_B_rebuild_one_pass_1687_1838.tcl only if both cumulative flows fail
3. backup_C_schema_probe_no_insert.tcl is retained as an older broad diagnostic,
   but the main Tcl's IEEE1838_PHASE=spec mode is now the preferred first run.

Main assumptions
- Pass 1 is RTL-level IEEE 1687 insertion.
- Pass 1 completed extract_icl and write_design -tsdb.
- Pass 1 PDL retargeting and RTL waveform simulation already pass.
- Pass 2 must not read golden RTL.
- Pass 2 must not re-add HostIjtag, SIB, or TDR.
- DWR insertion is intentionally outside the current main Tcl.

Die roles
- bottom: existing TAP becomes PTAP; add one STAP per directly connected upper die.
- middle: use the same flow only after bottom passes; add one STAP per directly connected upper die.
- top: blocked in the current main Tcl. Confirm the Tessent 2025.02 PTAP-only
  syntax locally before enabling a die with zero downstream STAPs.

First-run safety setting
- IEEE1838_PHASE=spec

Insertion safety settings
- IEEE1838_PHASE=insert
- CONFIRM_1838_SPEC=YES

Insertion outputs
- <top>_<die_position>_1687_1838_inserted.v
- <top>_<die_position>_1687_1838_extracted.icl
- <top>_<die_position>_1687_1838_import.tcl
- <top>_<die_position>_1687_1838.sdc

The SDC is not handwritten.  extract_icl generates the latest-pass SDC in:
  <tsdb>/dft_inserted_designs/
  <top>_<pass2_design_id>.dft_inserted_design/<top>.sdc
The main Tcl copies that generated file to OUTPUT_DIR for handoff.

Minimum acceptance checks
- one TAP/PTAP access root
- original local IJTAG PDL still retargets
- bottom/middle STAP reaches the next die PTAP
- no duplicated HostIjtag/SIB/TDR
- extracted ICL matches inserted RTL
