# =============================================================================
# Tessent 2025.02 RTL Pass 2 -- IEEE 1838 ONLY
#
# Goal:
#   Reuse/augment the already inserted IEEE 1687 TAP as the IEEE 1838 PTAP,
#   and add the STAP connection(s) required by this die.
#
# Deliberately excluded from this file:
#   - DWR insertion or DWR checking
#   - set_attribute_value
#   - attribute repair
#   - rebuilding HostIjtag/SIB/TDR
#   - re-reading golden RTL
#
# Required Pass 1 result:
#   - RTL-level IEEE 1687 insertion completed
#   - extract_icl completed
#   - write_design -tsdb completed
#   - PDL retargeting and RTL simulation already passed
#
# First run -- specification only, no RTL modification:
#   IEEE1838_PHASE=spec \
#   DIE_POSITION=bottom \
#   TOP_MODULE=basic_die_top \
#   TSDB_DIR=./tsdb_basic \
#   PASS1_DESIGN_ID=rtl_1687 \
#   STAP_HOST_LIST="s1" \
#   tessent -shell -dofile pass2_upgrade_1687_to_1838_rtl.tcl
#
# Continue to insertion only after the specification report proves:
#   1. The Pass 1 TAP is the TAP being augmented/reused as PTAP.
#   2. There is no second parallel HostScanInterface/Tap access root.
#   3. The existing HostIjtag/SIB/TDR is not recreated.
#   4. STAP host count equals the directly connected upper-die count.
#
# Second run -- perform IEEE 1838 insertion:
#   IEEE1838_PHASE=insert \
#   CONFIRM_1838_SPEC=YES \
#   DIE_POSITION=bottom \
#   TOP_MODULE=basic_die_top \
#   TSDB_DIR=./tsdb_basic \
#   PASS1_DESIGN_ID=rtl_1687 \
#   PASS2_DESIGN_ID=rtl_1687_1838_bottom \
#   STAP_HOST_LIST="s1" \
#   tessent -shell -dofile pass2_upgrade_1687_to_1838_rtl.tcl
#
# Immediate project target:
#   bottom Basic/ALU die -> STAP s1 -> middle Sensor 0 die
#
# Middle die uses the same flow with its own TOP_MODULE, TSDB, design IDs,
# and one STAP for the top Sensor 1 die.
#
# Top-die PTAP-only syntax is intentionally not guessed here.  Establish the
# bottom-die IEEE 1838 flow first.  Use local Tessent 2025.02 help/support-kit
# syntax before enabling a top die that has zero downstream STAPs.
# =============================================================================

proc env_or {name default_value} {
    global env
    if {[info exists env($name)] && $env($name) ne ""} {
        return $env($name)
    }
    return $default_value
}

proc required_env {name} {
    global env
    if {![info exists env($name)] || $env($name) eq ""} {
        error "Set required environment variable $name"
    }
    return $env($name)
}

proc env_bool {name default_value} {
    set raw [string tolower [env_or $name $default_value]]
    if {$raw in [list 1 true yes on]} {
        return 1
    }
    if {$raw in [list 0 false no off]} {
        return 0
    }
    error "$name must be one of: 1/0, true/false, yes/no, on/off"
}

proc split_host_list {raw} {
    set normalized [string map [list "," " " ";" " "] $raw]
    set result [list]
    foreach item [split $normalized] {
        if {$item ne ""} {
            lappend result $item
        }
    }
    return $result
}

set phase [string tolower [env_or IEEE1838_PHASE spec]]
if {$phase ni [list spec insert]} {
    error "IEEE1838_PHASE must be spec or insert"
}

set die_position [string tolower [env_or DIE_POSITION bottom]]
if {$die_position ni [list bottom middle top]} {
    error "DIE_POSITION must be bottom, middle, or top"
}

# Do not guess the top-die PTAP-only command.  This stop occurs before design
# loading, DFT specification creation, insertion, or TSDB writing.
if {$die_position eq "top"} {
    puts "TOP_DIE_BLOCKED:"
    puts "  The last die needs a PTAP and zero downstream STAPs."
    puts "  This template does not assume that an empty -stap_host_list"
    puts "  is accepted as PTAP-only by Tessent 2025.02."
    puts "  First complete the bottom-die IEEE 1838 flow."
    puts "  Then run 'help create_dft_specification' in the licensed"
    puts "  Multi-die environment and use the documented PTAP-only form."
    error "Top-die PTAP-only syntax has not been locally confirmed"
}

set top_module       [env_or TOP_MODULE basic_die_top]
set tsdb_dir         [file normalize [env_or TSDB_DIR ./tsdb_basic]]
set pass1_design_id  [env_or PASS1_DESIGN_ID rtl_1687]
set pass2_design_id  [env_or PASS2_DESIGN_ID rtl_1687_1838_${die_position}]
set output_dir       [file normalize [env_or OUTPUT_DIR ./generated_pass2]]
set write_flat_rtl   [env_bool WRITE_FLAT_RTL 1]
set stap_hosts       [split_host_list [required_env STAP_HOST_LIST]]

if {[llength $stap_hosts] == 0} {
    error "$die_position die requires at least one downstream STAP host"
}

if {$phase eq "insert"} {
    set confirmation [string toupper [env_or CONFIRM_1838_SPEC ""]]
    if {$confirmation ne "YES"} {
        error "Insertion is blocked. Inspect the spec-only report, then set CONFIRM_1838_SPEC=YES."
    }
}

set inserted_rtl       ${output_dir}/${top_module}_${die_position}_1687_1838_inserted.v
set extracted_icl      ${output_dir}/${top_module}_${die_position}_1687_1838_extracted.icl
set import_tcl         ${output_dir}/${top_module}_${die_position}_1687_1838_import.tcl
set exported_sdc       ${output_dir}/${top_module}_${die_position}_1687_1838.sdc
set tsdb_generated_sdc [file join \
    $tsdb_dir \
    dft_inserted_designs \
    ${top_module}_${pass2_design_id}.dft_inserted_design \
    ${top_module}.sdc]

puts "============================================================"
puts "IEEE1838_ONLY_CONFIG"
puts "  phase             = $phase"
puts "  die_position      = $die_position"
puts "  top_module        = $top_module"
puts "  tsdb_dir          = $tsdb_dir"
puts "  pass1_design_id   = $pass1_design_id"
puts "  pass2_design_id   = $pass2_design_id"
puts "  stap_hosts        = $stap_hosts"
puts "============================================================"

set_context dft -rtl -design_id $pass2_design_id
set_tsdb_output_directory $tsdb_dir

# Critical cumulative-flow rule:
# Load the verified Pass 1 design view.  Never read golden RTL in Pass 2.
read_design $top_module \
    -design_id $pass1_design_id \
    -verbose

set_current_design $top_module
set_design_level chip

puts "===== PASS1 ICL/TAP RECOGNITION ====="
if {[catch {report_module_matching -icl} matching_error]} {
    puts "WARNING: report_module_matching -icl failed or is unavailable:"
    puts "  $matching_error"
    puts "Do not insert until another local report proves that the Pass 1"
    puts "TAP/HostIjtag/SIB/TDR ICL is present and matched to this RTL view."
}

# Pass 1 already used the TAP host for the working IEEE 1687 network.
# No attribute is set or repaired in this Pass 2 file.
set_dft_specification_requirements -host_scan_interface_type tap
check_design_rules

# Tessent Multi-die request:
# Add STAP host(s) while augmenting/reusing the existing TAP as PTAP.
set spec [create_dft_specification \
    -stap_host_list $stap_hosts]

puts "===== IEEE 1838 GENERATED SPECIFICATION BEGIN ====="
report_config_data $spec
puts "===== IEEE 1838 GENERATED SPECIFICATION END ====="

puts "IEEE1838_MANUAL_GATE"
puts "  PASS only if the report shows all four conditions:"
puts {  [1] Existing Pass 1 TAP is reused/augmented as PTAP.}
puts {  [2] Exactly one TAP/PTAP access root exists.}
puts {  [3] Existing HostIjtag/SIB/TDR is not duplicated.}
puts "  \[4\] STAP hosts are exactly: $stap_hosts"

process_dft_specification -validate_only

if {$phase eq "spec"} {
    puts "IEEE1838_SPEC_PASS:"
    puts "  Specification validation completed."
    puts "  No process_dft_specification insertion was performed."
    puts "  No extract_icl, write_icl, or write_design was performed."
    puts "  Review the report before running IEEE1838_PHASE=insert."
    exit
}

puts "===== IEEE 1838 RTL INSERTION BEGIN ====="
process_dft_specification
extract_icl

file mkdir $output_dir

# Write a new, explicit ICL filename so the result cannot be confused with the
# Pass 1 extracted ICL or an older TSDB artifact.
write_icl \
    -output_file $extracted_icl \
    -modules [get_single_name [get_current_design]] \
    -hierarchical \
    -replace

# Save the cumulative IEEE 1687 + IEEE 1838 design as a separate Pass 2 view.
write_design -tsdb -verbose

if {$write_flat_rtl} {
    write_design \
        -output_file $inserted_rtl \
        -replace
}

# extract_icl generates the Tessent SDC in the Pass 2 TSDB design directory.
# Copy that exact latest-pass SDC to the explicit output directory for
# synthesis/STA handoff.  Do not create a handwritten substitute.
if {![file exists $tsdb_generated_sdc]} {
    error "Tessent SDC was not generated at expected path: $tsdb_generated_sdc"
}

file copy -force \
    $tsdb_generated_sdc \
    $exported_sdc

write_design_import_script \
    $import_tcl \
    -replace \
    -use_relative_path_to [pwd]

puts "===== IEEE 1838 RTL INSERTION COMPLETE ====="
puts "Inserted RTL : $inserted_rtl"
puts "Extracted ICL: $extracted_icl"
puts "Import Tcl   : $import_tcl"
puts "Tessent SDC  : $exported_sdc"
puts "TSDB SDC     : $tsdb_generated_sdc"
puts "TSDB         : $tsdb_dir"
puts "Design ID    : $pass2_design_id"
puts "NEXT_ACTION:"
puts "  Retarget and simulate the already working local IJTAG PDL through"
puts "  this Pass 2 ICL. Do not begin DWR insertion or attribute repair yet."
exit
